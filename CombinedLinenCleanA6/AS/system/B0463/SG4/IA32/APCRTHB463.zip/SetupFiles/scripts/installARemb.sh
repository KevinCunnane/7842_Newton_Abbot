#!/bin/bash
############################################################################
# installARemb.sh - A menu driven shell script to install ARemb on an APC. #
############################################################################

NO_UEFI_SUPPORT=1

# print debug messages and optionally just simulate the action
DEBUG=
NO_ACTION=
NO_ACTION_PARAM="NO_ACTION"

while [ -n "$1" ]
do
	if [ "$1" = $NO_ACTION_PARAM ]; then
		NO_ACTION=$1
	fi
	shift
done

SETUP_DIR="/Setup"
ROOT_DIR="/root"
BASEAR_DIR=$ROOT_DIR"/BaseAR"
SHELL_SCRIPT_DIR=$ROOT_DIR"/scripts"
BOOT_INFO_DIR=$SHELL_SCRIPT_DIR
WINDOWS_EFI_FILE="bootmgfw.efi"

BOOT_INFO_RESULT_FILE=$BOOT_INFO_DIR/RESULTS.txt
RTH_TRACE_FILE=log.txt
RTH_LOG_LEVEL=8
INSTALL_LOG_FILE=$SETUP_DIR"/install_log.txt"
MIN_AR_PARTITION_SIZE=255			# Mindestgroesse der freien Partition fuer das AR

# Define variables
LSB=/usr/bin/lsb_release

# include scripts
source "${SHELL_SCRIPT_DIR}/info.sh"			# info.sh is generated via extinst AR build
source "${SHELL_SCRIPT_DIR}/guiHelper.sh"
source "${SHELL_SCRIPT_DIR}/helper.sh"
source "${SHELL_SCRIPT_DIR}/installGrub2.sh"
source "${SHELL_SCRIPT_DIR}/saveBootLoader.sh"
source "${SHELL_SCRIPT_DIR}/handleExtendedPartition.sh"
source "${SHELL_SCRIPT_DIR}/installHypervisor.sh"
source "${SHELL_SCRIPT_DIR}/installInitialARemb.sh"
source "${SHELL_SCRIPT_DIR}/uefiEsp.sh"
source "${SHELL_SCRIPT_DIR}/uefiGuiMenu.sh"
source "${SHELL_SCRIPT_DIR}/uefiHypervisor.sh"
source "${SHELL_SCRIPT_DIR}/uefiInstallation.sh"
source "${SHELL_SCRIPT_DIR}/uefiInstallGrub2.sh"
source "${SHELL_SCRIPT_DIR}/uefiUninstallation.sh"

AREMB_DIALOG_INSTALL_TITLE="B&R Hypervisor Installation"
AREMB_DIALOG_INSTALL_BACKTITLE="B&R Hypervisor Installation"
AREMB_DIALOG_UNINSTALL_TITLE="B&R Hypervisor Uninstallation"
AREMB_DIALOG_UNINSTALL_BACKTITLE="B&R Hypervisor Uninstallation"
AREMB_DIALOG_PARTITIONS_TITLE="Show partitions"
AREMB_DIALOG_EXISTING_EXTENDED_PARTITION_TITLE="Already existing extended partition"
GO_BACK_LABEL="Go back"
OK_LABEL="OK"
INSTALL_LABEL="Install"
UNINSTALL_LABEL="Uninstall"
EXIT_LABEL="Exit"
NEXT_LABEL="Next"
RESTART_LABEL="Restart"

DIALOG_INSTALL_STATUS=0				#$DIALOG_OK
DIALOG_UNINSTALL_STATUS=0			#$DIALOG_OK
DIALOG_OK_STATUS=0					#$DIALOG_OK
DIALOG_BACK_STATUS=0				#$DIALOG_OK
DIALOG_NEXT_STATUS=3				#$DIALOG_EXTRA
DIALOG_CANCEL_STATUS=1				#$DIALOG_CANCEL

# constants
MAIN_MENU_INST_IDX=1
INST_CFG_AREMB_IDX=3

INST_CFG_SUMMARY_IDX=5
INST_START_IDX=6
INST_FINISHED_IDX=7

MAIN_MENU_UNINST_IDX=20
UNINST_CFG_AREMB_IDX=21
UNINST_CFG_SUMMARY_IDX=22
UNINST_START_IDX=23
UNINST_FINISHED_IDX=24

SHOW_PARTITIONS_IDX=40

pageIdx=
uefiInstall=

function _readGrub2Installation() {
	local __isAlreadyInstalled=$1
	local device=$2

	for d in $(sed -ne 's/^.*\(sd.*\)/\1/p' /proc/partitions);do
		echo -e "$d\t ID: $(sudo hexdump -v -s 0x80 -n 2 -e '2/1 "%x" "\n"' /dev/$d)";
	done;
	echo -e "\t(G1) 5272/aa75 (G2) 48b4/7c3c/020 (Core) 488/31d2"
}

function _readPartitionLabel() {
	local __label=$1
	local device=$2
	local partNr=$3
	local fileSystem=$4

	checkLastParam $partNr "no partition number given."

	local label=
	local arembSetup="0"
	if [[ "$fileSystem" =~ "fat" ]]; then		#fat16 and fat32
		label=$(dosfslabel $device$partNr)

	elif [ "$fileSystem" = "ntfs" ]; then
		label=$(ntfslabel $device$partNr)

	elif [ "$fileSystem" = "ext2" ] || [ "$fileSystem" = "ext3" ] || [ "$fileSystem" = "ext4" ]; then
		label=$(e2label $device$partNr)
	fi

	eval "${__label}='${label}'"
}

function _getFreeSpace()
{
	local __freeSpace=$1
	local devicePartNr=$2
	local free=
	local freeDir
	local i

	checkLastParam $devicePartNr "no device partNr given."

	mountPartition freeDir $devicePartNr

	local OIFS=$IFS
	IFS=$'\n'
	local dfOutput=$(df -m $freeDir)
	local arr=$dfOutput
	for i in $arr
	do
		if [ -n "$i" ]; then
			if [ "${i:0:10}" = "Filesystem" ]; then
				availableStart=$(echo "$i" | awk '{ print index ($0, "Available")-1;}')
			else
				free=$(echo ${i:$availableStart:9} | sed 's/ //g')
				break
			fi
		fi
	done
	IFS=$OIFS
	umount $freeDir
	eval "${__freeSpace}='${free}'"
}

function _readSingleDrive() {
	local drive=$1
	local driveSize=$2
	local driveLogSectorSize=$3
	local drivePhysSectorSize=$4
	local drivePartTable=$5
	local driveDesc=$6
	local driveNumber=$7
	local i

	checkLastParam $driveNumber "no drive number given."

	# read partition info
	local OIFS=$IFS
	IFS=$'\n'
	#local partedOutput=$(parted -s $drive unit MB print | sed 's/  */ /g')
	local partedOutput=$(parted -s $drive unit MB print free)
	local arr=$partedOutput
	local nextIsAPartition="0"
	local extendedPartNr=
	for i in $arr
	do
		if [ -n "$i" ]; then
			firstHead=$(echo $i | cut -d ' ' -f 1)
			if [ "$firstHead" = "Number" ]; then
				nextIsAPartition="1"
				extendedPartNr=
				ignoreDisk=
				local numberStart=$(echo "$i" | awk '{ print index ($0, "Number");}')		#index of "Number"
				local startStart=$(echo "$i" | awk '{ print index ($0, "Start")-1;}')
				local endStart=$(echo "$i" | awk '{ print index ($0, "End")-1;}')
				local sizeStart=$(echo "$i" | awk '{ print index ($0, "Size")-1;}')
				if [ "$drivePartTable" = "msdos" ]; then
					local typeStart=$(echo "$i" | awk '{ print index ($0, "Type")-1;}')
				else
					local nameStart=$(echo "$i" | awk '{ print index ($0, "Name")-1;}')
				fi
				local fileSystemStart=$(echo "$i" | awk '{ print index ($0, "File system")-1;}')
				local flagsStart=$(echo "$i" | awk '{ print index ($0, "Flags")-1;}')
			else
				if [ "$nextIsAPartition" = "1" ]; then
					local partNr=$(echo ${i:$numberStart} | cut -d ' ' -f 1)
					local start=$(echo ${i:$startStart} | cut -d ' ' -f 1)
					local end=$(echo ${i:$endStart} | cut -d ' ' -f 1)
					local size=$(echo ${i:$sizeStart} | cut -d ' ' -f 1)
					if [ "$drivePartTable" = "msdos" ]; then
						type=$(echo ${i:$typeStart} | cut -d ' ' -f 1)
					else
						name=$(echo ${i:$nameStart} | cut -d ' ' -f 1)
					fi
					local fileSystem=$(echo ${i:$fileSystemStart} | cut -d ' ' -f 1)
					local flags=${i:$flagsStart}

					# hide partitions < 2MB
					local sizeInMB=${size//MB/}	# "MB" => ""
					if (( ( $(echo "${sizeInMB} < 2" | bc -l) ) )); then
						continue
					fi

					local correspondingExtPartNr=$extendedPartNr
					local partLabel=
					local freeSpaceInMb=

					if [ "$drivePartTable" = "msdos" ]; then
						if $( echo $fileSystem | grep -q 'linux-swap' ); then
							partLabel="swap"
						elif [ "$type" = "extended" ]; then
							extendedPartNr=${#partitionDevice[@]}
							partLabel="extended"
							fileSystem="-"
						elif [ -n "$partNr" ]; then
							_readPartitionLabel partLabel $drive $partNr $fileSystem
							_getFreeSpace freeSpaceInMb $drive$partNr
						else
							partLabel=
							freeSpaceInMb=$sizeInMB
						fi
					else
						partLabel=$name
						if [ -z "$partNr" ]; then
							partLabel="unallocated"
						fi
						if [ -z "$fileSystem" ]; then
							fileSystem="unknown"
						fi
					fi

					if [ -z "$freeSpaceInMb" ]; then
						freeSpaceInMb="0"
					fi

					if [ -z "$partLabel" ]; then
						partLabel="untitled"
					fi

					# hide ARemb Install Stick and B&R dongle
					if [ "${partLabel}" == "AREMB-SETUP" ] || [ "${partLabel}" == "CODEMETER  " ]; then
						ignoreDisk=1
					fi

					if [ "$ignoreDisk" = "1" ]; then
						continue
					fi

					local shortPartName=${drive:5}$partNr
					local grubCfg=$(awk -v DEVICE=$shortPartName -f ${SHELL_SCRIPT_DIR}/getGrubCfg.awk $BOOT_INFO_RESULT_FILE)

					if [ -n "$grubCfg" ]; then
						grubPartNr=$partNr
					else
						grubCfg="-"
						grubPartNr=
					fi

					# searches for a line containing "<XXX> is installed in the MBR of <YYY>"
					# 						  eg.: "Windows is installed in the MBR of /dev/sda"
					local gposString=$(grep " is installed in the MBR of $drive" $BOOT_INFO_RESULT_FILE | cut -d ' ' -f 3)
					if [ -z "$gposString" ]; then
						gposString="-"
					else
						if [ "$gposString" != "Windows" ]; then
							gposString="Linux"
						fi
					fi

					# save parameters in global arrays
					partitionDevice=("${partitionDevice[@]}" "$drive")
					partitionDiskNumber=("${partitionDiskNumber[@]}" "$driveNumber")
					partitionDeviceSize=("${partitionDeviceSize[@]}" "$driveSize")
					partitionDeviceLogSectorSize=("${partitionDeviceLogSectorSize[@]}" "$driveLogSectorSize")
					partitionDevicePhysSectorSize=("${partitionDevicePhysSectorSize[@]}" "$drivePhysSectorSize")
					partitionDevicePartTable=("${partitionDevicePartTable[@]}" "$drivePartTable")
					partitionDeviceDesc=("${partitionDeviceDesc[@]}" "$driveDesc")

					partitionPartNr=("${partitionPartNr[@]}" "$partNr")
					partitionFs=("${partitionFs[@]}" "$fileSystem")
					if [ "$drivePartTable" = "msdos" ]; then
						partitionType=("${partitionType[@]}" "$type")
					fi
					local sizeInMb=${size//MB/}	# "MB" => ""
					partitionSize=("${partitionSize[@]}" "$sizeInMb")
					partitionFree=("${partitionFree[@]}" "$freeSpaceInMb")
					partitionStart=("${partitionStart[@]}" "$start")
					partitionEnd=("${partitionEnd[@]}" "$end")
					partitionLabel=("${partitionLabel[@]}" "$partLabel")
					partitionFlag=("${partitionFlag[@]}" "$flags")
					partitionExtPartNr=("${partitionExtPartNr[@]}" "$correspondingExtPartNr")

					partitionDeviceGrubPartNr=("${partitionDeviceGrubPartNr[@]}" "$grubPartNr")
					partitionDeviceGrubCfg=("${partitionDeviceGrubCfg[@]}" "$grubCfg")
					partitionDeviceGposString=("${partitionDeviceGposString[@]}" "$gposString")

					if [ "1" = "0" ]; then
						echo "drive:$drive"
						echo "diskNumber:$driveNumber"
						echo "driveSize:$driveSize"
						echo "driveLogSectorSize:$driveLogSectorSize"
						echo "drivePhysSectorSize:$drivePhysSectorSize"
						echo "drivePartTable:$drivePartTable"
						echo "driveDesc:$driveDesc"
						echo "partNr:$partNr"
						echo "fileSystem:$fileSystem"
						echo "type:$type"
						echo "sizeInMb:$sizeInMb (MB)"
						echo "freeSpaceInMb:$freeSpaceInMb (MB)"
						echo "start:$start"
						echo "end:$end"
						echo "partLabel:$partLabel"
						echo "flags:$flags"
						echo "correspondingExtPartNr:$correspondingExtPartNr"
						echo "grubPartNr:$grubPartNr"
						echo "grubCfg:$grubCfg"
						echo "gposString:$gposString"
						pause
					fi
				fi
			fi
		fi
	done
	IFS=$OIFS
}

function _readDrives(){
	# delete arrays contents
	partitionDevice=()
	partitionDiskNumber=()
	partitionDeviceSize=()
	partitionDeviceLogSectorSize=()
	partitionDevicePhysSectorSize=()
	partitionDevicePartTable=()
	partitionDeviceDesc=()
	partitionDeviceGrubPartNr=()
	partitionDeviceGrubCfg=()
	partitionDeviceGposString=()

	partitionPartNr=()
	partitionFs=()
	partitionType=()
	partitionSize=()
	partitionFree=()
	partitionStart=()
	partitionEnd=()
	partitionLabel=()
	partitionFlag=()
	partitionExtPartNr=()

	local drives=()
	local driveNumbers=()
	local driveSizes=()
	local driveLogSectorSizes=()
	local drivePhysSectorSizes=()
	local drivePartTables=()
	local driveDescs=()
	local i

	local usbDevice=$(mount | grep $SETUP_DIR | cut -d ' ' -f 1)
	usbDevice=${usbDevice:0:8}		#removing partition number

	# read all drives
	local OIFS=$IFS
	IFS=$'\n'
	local partedOutput=$(parted -l -m)
	local arr=$partedOutput
	for i in $arr
	do
		if [ -n "$i" ]; then
			if [ "$i" = "BYT;" ]; then
				nextIsADevice="1"
				let cnt=cnt+1
			else
				if [ "$nextIsADevice" = "1" ]; then
					nextIsADevice="0"
					local device=$(echo $i | cut -d ':' -f 1)
					local size=$(echo $i | cut -d ':' -f 2)
					local logSectorSize=$(echo $i | cut -d ':' -f 4)
					local physSectorSize=$(echo $i | cut -d ':' -f 5)
					local partTable=$(echo $i | cut -d ':' -f 6)
					local desc=$(echo $i | cut -d ':' -f 7)
					desc=${desc//;/}

					logWriteDeviceInfo $device

					# filter out usb install stick device
					if [ "$usbDevice" != "$device" ] ; then
						_getDiskNumberOfDevice deviceNumber $device

						drives=("${drives[@]}" "$device")
						driveNumbers=("${driveNumbers[@]}" "$deviceNumber")
						driveSizes=("${driveSizes[@]}" "$size")
						driveLogSectorSizes=("${driveLogSectorSizes[@]}" "$logSectorSize")
						drivePhysSectorSizes=("${drivePhysSectorSizes[@]}" "$physSectorSize")
						drivePartTables=("${drivePartTables[@]}" "$partTable")
						driveDescs=("${driveDescs[@]}" "$desc")
					fi
				fi
			fi
		fi
	done
	IFS=$OIFS

	# read boot info (grub.cfg)
	rm -f $BOOT_INFO_RESULT_FILE
	$SHELL_SCRIPT_DIR/bootinfoscript

	# read partition info of each drive
	for (( i=0; i<${#drives[@]}; i++ ))
	do
		_readSingleDrive "${drives[$i]}" "${driveSizes[$i]}" "${driveLogSectorSizes[$i]}" \
		"${drivePhysSectorSizes[$i]}" "${drivePartTables[$i]}" "${driveDescs[$i]}" "${driveNumbers[$i]}"
	done

	local j=
	### drive spezifische Werte nachziehen
	for (( j=0; j<${#drives[@]}; j++ ))
	do
		local currDrive=${drives[$j]}
		local deviceGrubPartNr=1		# default value if using windows
		local deviceGrubCfg="-" 		# default value if using windows

		for (( i=0; i<${#partitionDevice[@]}; i++ ))
		do
			local currDevice=${partitionDevice[$i]}
			if [ "$currDrive" = "$currDevice" ] ; then
				if [ "$deviceGrubCfg" = "-" ]; then
					if [ -n "${partitionDeviceGrubPartNr[$i]}" ]; then
						deviceGrubPartNr=${partitionDeviceGrubPartNr[$i]}
						deviceGrubCfg=${partitionDeviceGrubCfg[$i]}
						i="-1"			# for schleife ein zweites mal durchlaufen
					fi
				else		# bei den anderen partitionen nachziehen
					partitionDeviceGrubPartNr[$i]=$deviceGrubPartNr
					partitionDeviceGrubCfg[$i]=$deviceGrubCfg
				fi
			fi
		done
	done

	logWriteDebug "device and partition information:"
	# read partition info of each drive
	for (( i=0; i<${#partitionDevice[@]}; i++ ))
	do
		logWriteDebug "${partitionDevice[$i]}${partitionPartNr[$i]}, ${partitionDiskNumber[$i]}: ${partitionDeviceSize[$i]}, ${partitionDeviceLogSectorSize[$i]}, ${partitionDevicePhysSectorSize[$i]}, ${partitionDevicePartTable[$i]}, ${partitionDeviceDesc[$i]}, ${partitionDeviceGrubPartNr[$i]}, ${partitionDeviceGrubCfg[$i]}, ${partitionDeviceGposString[$i]}"
		logWriteDebug "    ${partitionFs[$i]}, ${partitionType[$i]}, ${partitionSize[$i]}, ${partitionFree[$i]}, ${partitionStart[$i]}, ${partitionEnd[$i]}, ${partitionLabel[$i]}, ${partitionFlag[$i]}, ${partitionExtPartNr[$i]}"
	done
}

function _printPartitions(){
	if [ "1" = "0" ]; then
		logWriteDebug "name: $1, cnt: $2, default: $3"
		shift
		shift
		shift
	
		while [ -n "$1" ]
		do
			logWriteDebug "$1 $2"
			shift
			shift
		done
		logWriteDebug ""
	fi
}

function _getPartitionString() {
	local __partString=$1
	local i=$2

	local partStr=

	partStr="${partitionDeviceDesc[$i]} (${partitionDeviceSize[$i]})"
	if [ -z "${partitionType[$i]}" ]; then
		partStr="${partStr}, unallocated"
	elif [ "${partitionType[$i]}" = "extended" ]; then
		partStr="${partStr}, extended partition"
	else
		partStr="${partStr}, ${partitionLabel[$i]}, ${partitionDeviceGposString[$i]}"
	fi

	#if (( (${partitionPartNr[$i]} >= 5) )); then			# logical drives
		#	partStr="  "${partitionLabel[$i]}
	#fi

	partStr="disk${partitionDiskNumber[$i]}: $partStr, ${partitionSize[$i]}MB (free:${partitionFree[$i]}MB) ${partitionFs[$i]}"
	eval "${__partString}='${partStr}'"
}

function _getARembInstallationCandidate() {
	local __driveString=$1
	local device=$2

	local j=
	local driveString=

	for (( j=0; j<${#partitionDevice[@]}; j++ ))
	do
		# loop until unpartitioned/unallocated space
		if [ "${partitionDevice[$j]}" = "$device" ]; then
			if [ -z "${partitionType[$j]}" ] && (( ( ${partitionFree[$j]} > $MIN_AR_PARTITION_SIZE) )); then
				driveString="disk$driveNr: ${partitionDeviceGposString[$j]} on ${partitionDeviceDesc[$j]} (${partitionDeviceSize[$j]}, ${partitionFree[$j]}MB free) "
				break
			fi
		fi
	done
	eval "${__driveString}='${driveString}'"
}

function _getARembDeinstallationCandidate() {
	local __driveString=$1
	local device=$2

	local j=
	local driveString=

	for (( j=0; j<${#partitionDevice[@]}; j++ ))
	do
		# loop until extended partition
		if [ "${partitionDevice[$j]}" = "$device" ]; then
			if [ "${partitionType[$j]}" = "extended" ]; then
				driveString="disk$driveNr: ${partitionDeviceGposString[$j]} on ${partitionDeviceDesc[$j]} (${partitionDeviceSize[$j]})"
				break
			fi
		fi
	done
	eval "${__driveString}='${driveString}'"
}

# all disk candidates on which ARemb can be installed
# i.e.: there is no extended partition on the disk
function _createARembInstallationCandidates(){
	AREMB_CAND_PART_COUNTER=1
	AREMB_CAND_PART_LIST=()  # variable for possible bootable partitions
	AREMB_CAND_PART_IDX_LIST=()
	defaultCandPartitionNr=0
	local currDevice=

	for (( i=0; i<${#partitionDevice[@]}; i++ ))
	do
		if [ "$currDevice" != "${partitionDevice[$i]}" ] ; then	# each disk just once
			currDevice=${partitionDevice[$i]}

			_getARembInstallationCandidate candDriveString $currDevice

			if [ -n "$candDriveString" ]; then
				AREMB_CAND_PART_LIST=("${AREMB_CAND_PART_LIST[@]}" "$AREMB_CAND_PART_COUNTER")
				AREMB_CAND_PART_LIST=("${AREMB_CAND_PART_LIST[@]}" "$candDriveString")
				AREMB_CAND_PART_IDX_LIST=("${AREMB_CAND_PART_IDX_LIST[@]}" "$i")
				if [ "$defaultCandPartitionNr" = "0" ]; then
						let defaultCandPartitionNr=$AREMB_CAND_PART_COUNTER
				fi
				let AREMB_CAND_PART_COUNTER=AREMB_CAND_PART_COUNTER+1
			fi
		fi
	done
	_printPartitions "CAND_PART" $AREMB_CAND_PART_COUNTER $defaultCandPartitionNr ${AREMB_CAND_PART_IDX_LIST[@]} ${AREMB_CAND_PART_LIST[@]}
}

# all disk candidates on which ARemb is installed
# i.e.: there is an extended partition on the disk
function _createARembDeinstallationCandidates(){
	EXTENDED_PART_COUNTER=1
	EXTENDED_PART_LIST=()
	EXTENDED_PART_IDX_LIST=()
	defaultExtendedPartitionNr=0
	local currDevice=

	for (( i=0; i<${#partitionDevice[@]}; i++ ))
	do
		if [ "$currDevice" != "${partitionDevice[$i]}" ] ; then	# each disk just once
			currDevice=${partitionDevice[$i]}
			
			_getARembDeinstallationCandidate candDriveString $currDevice
	
			if [ -n "$candDriveString" ]; then
				EXTENDED_PART_LIST=("${EXTENDED_PART_LIST[@]}" "$EXTENDED_PART_COUNTER")
				EXTENDED_PART_LIST=("${EXTENDED_PART_LIST[@]}" "$candDriveString")
				EXTENDED_PART_IDX_LIST=("${EXTENDED_PART_IDX_LIST[@]}" "$i")
				if [ "$defaultExtendedPartitionNr" = "0" ]; then
					let defaultExtendedPartitionNr=$EXTENDED_PART_COUNTER
				fi
				let EXTENDED_PART_COUNTER=$EXTENDED_PART_COUNTER+1
			fi
		fi
	done
	_printPartitions "EXTENDED" $EXTENDED_PART_COUNTER $defaultExtendedPartitionNr ${EXTENDED_PART_IDX_LIST[@]} ${EXTENDED_PART_LIST[@]}
}

function _createPartitionInfoStrings(){
	ALL_PART_COUNTER=1
	ALL_PART_LIST=()  # variable where we will keep the list entries for menu dialog
	ALL_PART_IDX_LIST=()

	# all bootable partitions
	BOOT_PART_COUNTER=1
	BOOT_PART_LIST=()
	BOOT_PART_IDX_LIST=()
	defaultbootPartitionNr=0

	partitionComplete=()
	partitionCnt=0
	for (( i=0; i<${#partitionDevice[@]}; i++ ))
	do
		_getPartitionString candPartString $i

		# all partitions
		ALL_PART_LIST=("${ALL_PART_LIST[@]}" "$ALL_PART_COUNTER")
		ALL_PART_LIST=("${ALL_PART_LIST[@]}" "$candPartString")
		ALL_PART_IDX_LIST=("${ALL_PART_IDX_LIST[@]}" "$i")
		let ALL_PART_COUNTER=ALL_PART_COUNTER+1

		# all bootable partitions
		if [[ "${partitionFlag[$i]}" =~ "boot" ]]; then
			BOOT_PART_LIST=("${BOOT_PART_LIST[@]}" "$BOOT_PART_COUNTER")
			BOOT_PART_LIST=("${BOOT_PART_LIST[@]}" "$candPartString")
			BOOT_PART_IDX_LIST=("${BOOT_PART_IDX_LIST[@]}" "$i")
			if [ "$defaultbootPartitionNr" = "0" ]; then
				let defaultbootPartitionNr=$BOOT_PART_COUNTER
				bootPartitionNr=$i
			fi
			let BOOT_PART_COUNTER=BOOT_PART_COUNTER+1
		fi

		partitionComplete=("${partitionComplete[@]}" "$candPartString")
		let partitionCnt=$partitionCnt+1
	done

	_printPartitions "ALL_PART" $ALL_PART_COUNTER 0 ${ALL_PART_IDX_LIST[@]} ${ALL_PART_LIST[@]}
	_printPartitions "BOOT" $BOOT_PART_COUNTER $defaultbootPartitionNr ${BOOT_PART_IDX_LIST[@]} ${BOOT_PART_LIST[@]}
	_printPartitions "ALL" $partitionCnt 0 ${partitionComplete[@]}
}

function getExtendedPartIdx() {
	local __extPartIdx=$1
	local device=$2
	local extPartIndex=

	checkLastParam $device "no device given."

	for (( i=0; i<${#partitionDevice[@]}; i++ ))
	do
		if [ "${partitionDevice[$i]}" = "$device" ]; then
			if [ "${partitionType[$i]}" = "extended" ]; then
				extPartIndex=$i
				break
			fi
		fi
	done

	eval "$__extPartIdx='$extPartIndex'"
}

# ignore CTRL+C, CTRL+Z and quit singles using the trap
trap '' SIGINT SIGQUIT

trap ctrl_z SIGTSTP
function ctrl_z() { echo "** trapped Crtl-Z";   exit 0; }

trap ctrl_c INT
function ctrl_c() { echo "** Trapped CTRL-C";   exit 0; }

# for testing, on real system wait 5 seconds only
myhostname=$(hostname)
if [ "$myhostname" = "buildroot" ]; then
	: #sleep 5 TODO enablen
fi

tempfile=./tempfile.txt

#############################################
# Receives the result given in the file in the first parameter from the dialog
function _receiveResult(){
   retv=$?
   if [ -f $1 ] ; then
       choice=$(cat $1)
   fi
   [ $retv -eq 1 -o $retv -eq 255 ] && exit
}

function _showMainMenuInstallDialog(){
	local menuList=("1" "Install" "2" "Show partitions")

    dialog --title "$AREMB_DIALOG_INSTALL_TITLE" --backtitle "$AREMB_DIALOG_INSTALL_BACKTITLE" \
        --cancel-label "Exit" \
        --menu "\nPlease choose an option:\n \n" 15 55 3 "${menuList[@]}" 2> $tempfile
	_receiveResult $tempfile

	case $choice in
    	1) setPageIdx $INST_CFG_AREMB_IDX ;;
    	2) setPageIdx $SHOW_PARTITIONS_IDX ;;
	esac
}

function _showMainMenuUninstallDialog(){
	local menuList=("1" "Uninstall" "2" "Show partitions")

    dialog --title "$AREMB_DIALOG_INSTALL_TITLE" --backtitle "$AREMB_DIALOG_INSTALL_BACKTITLE" \
        --cancel-label "Exit" \
        --menu "\nPlease choose an option:\n \n" 15 55 3 "${menuList[@]}" 2> $tempfile
	_receiveResult $tempfile

	case $choice in
    	1) setPageIdx $UNINST_CFG_AREMB_IDX ;;
    	2) setPageIdx $SHOW_PARTITIONS_IDX ;;
	esac
}

# Shows all existing drives with all partitions
function _showPartitionInfoDialog() {
	title=$1
	backtitle=$2
	menu=$3
	defaultitem=$4
	count=$5
	shift
	shift
	shift
	shift
	shift

	dialog --title "$title" --backtitle "$backtitle" \
                --ok-label "$GO_BACK_LABEL" --extra-button --extra-label "$NEXT_LABEL" --default-button extra \
                --default-item "$defaultitem" \
                --menu "$menu" 20 120 $count \
"$@" 2> $tempfile
    _receiveResult $tempfile
}

function _showInstCfgARembPartDialog(){
    _showPartitionInfoDialog "$AREMB_DIALOG_INSTALL_TITLE - Select disk for ARemb" "$AREMB_DIALOG_INSTALL_BACKTITLE" "\
\nPlease select the disk for ARemb: \n \n"\
 "$defaultCandPartitionNr" $AREMB_CAND_PART_COUNTER "${AREMB_CAND_PART_LIST[@]}"

	if (( ("$retv" == "$DIALOG_NEXT_STATUS") )); then
		let choice=$choice-1
		ARembPartitionNr=${AREMB_CAND_PART_IDX_LIST[$choice]}
		setPageIdx $INST_CFG_SUMMARY_IDX			#ok
	else
		goBack
	fi
}

function _showPartitionsDialog(){
    _showPartitionInfoDialog "$AREMB_DIALOG_PARTITIONS_TITLE" "$AREMB_DIALOG_INSTALL_BACKTITLE" "\
\nAvailable drives: \n \n"\
 "0" $ALL_PART_COUNTER "${ALL_PART_LIST[@]}"

    goBack
}

function _checkForEspPartitionOnMsdos()
{
	for (( i=0; i<${#partitionFlag[@]}; i++ ))
	do
		getEspPartition espDevice espPartition
		if [ -n "$espDevice" ]  && [ -n "$espPartition" ]; then
			logWriteDebug "The msdos disk contains an ESP."

			_showErrorDialogWithRestart "$AREMB_DIALOG_LEGACY_GPOS_INSTALLATION" \
"Your disk is initialized with an msdos partition table, however there is an EFI system partition (ESP) available. You cannot install B&R Hypervisor on an msdos disk with an ESP.\n
- initialize your disk with a gpt partition table and reinstall UEFI GPOS with an ESP (recommended) or\n
- install legacy GPOS without an ESP.

Please restart and choose the UEFI boot option."
		fi
	done
}

function _showInstCfgSummaryDialog(){
	local arembDevice=${partitionDevice[$ARembPartitionNr]}
	local arembDisk=${partitionDiskNumber[$ARembPartitionNr]}
	local arembFree=${partitionFree[$ARembPartitionNr]}
	local arembDiskDesc=${partitionDeviceDesc[$ARembPartitionNr]}
	local diskGpos=${partitionDeviceGposString[$ARembPartitionNr]}
	local dialogText=

    _checkForEspPartitionOnMsdos $arembDevice

	dialogText=\
"\nPending operations:\n\n\
1. Save MBR\n\
2. Create partitions for B&R Hypervisor and ARemb on disk${arembDisk}: ${arembDiskDesc}, ${diskGpos} \n\
3. Install B&R Hypervisor\n\
4. Install ARemb\n\
5. Install Grub2 into MBR\n\nExecute?\n \n"

	dialog --title "$AREMB_DIALOG_INSTALL_TITLE - Configuration summary" --backtitle "$AREMB_DIALOG_INSTALL_BACKTITLE" --cr-wrap \
                --ok-label "$INSTALL_LABEL" \
                --extra-button --extra-label "$GO_BACK_LABEL" \
                --no-label "$EXIT_LABEL" \
                --yesno \
                "$dialogText" 17 120
                _receiveResult $tempfile

    if (( ("$retv" == "$DIALOG_INSTALL_STATUS") )); then
    	setPageIdx $INST_START_IDX					#install
	else											#back
		goBack
	fi
}

function _install(){
	local bootDevice=${partitionDevice[$bootPartitionNr]}
	local bootPartNr=${partitionDeviceGrubPartNr[$bootPartitionNr]}
	local bootGrubCfg=${partitionDeviceGrubCfg[$bootPartitionNr]}

	local detectedGpos=${partitionDeviceGposString[$bootPartitionNr]}

	if [ -z "$bootPartNr" ]; then
		bootPartNr=1				# partition number where to save the MBR
	fi

	local gposDevice=$bootDevice
	local gposPartNr=$bootPartNr

	local arembDevice=${partitionDevice[$ARembPartitionNr]}

	showInstProgress "0"
	logWriteInstallStart

	saveBootLoader $bootDevice $gposPartNr
	showInstProgress "10"

	local extendedPartitionSizeInMb=
	getExtendedPartitionSize extendedPartitionSizeInMb $arembDevice
	showInstProgress "20"

	if [ "$extendedPartitionSizeInMb" != "0" ]; then
		_showErrorDialog "$AREMB_DIALOG_EXISTING_EXTENDED_PARTITION_TITLE" \
			"Please choose another disk or delete extended partition before installation of B&R Hypervisor"

	else
		local logSectSize=${partitionDeviceLogSectorSize[$ARembPartitionNr]}
		createExtendedPartition $arembDevice $logSectSize
		showInstProgress "30"
	fi

	createARembPartitions arembPartNumber $arembDevice $logSectSize
	showInstProgress "40"

	installHypervisorFiles $arembDevice $arembPartNumber
	showInstProgress "50"

	installInitialARemb $arembDevice $arembPartNumber
	showInstProgress "60"

	installGrub2 $bootDevice $bootPartNr $gposDevice $gposPartNr $detectedGpos $bootGrubCfg $arembDevice $arembPartNumber
	showInstProgress "70"

	getBootLine bootLine $bootDevice $bootPartNr $detectedGpos $bootGrubCfg
	getExtendedPartitionNumber extPartNr $arembDevice
	showInstProgress "80"

	installHypervisorCfg "$gposDevice" "$arembDevice" "$arembPartNumber" "$extPartNr" "$detectedGpos" "$bootLine"
	showInstProgress "90"

	logWriteInstallFinished
	showInstProgress "100"

	pageIdx=$INST_FINISHED_IDX
}

function _showRebootDialog(){
	local title=$1
	local text=$2

	checkLastParam $text "no text given."

	logWriteDebug "reboot dialog: $title - $text"

    dialog --title "$title" --backtitle "$AREMB_DIALOG_INSTALL_BACKTITLE" --cr-wrap \
                --ok-label "$RESTART_LABEL"\
                --msgbox "\n$text\n\nSystem will be restarted." 10 80
                _receiveResult $tempfile

	umount $SETUP_DIR
    $SHELL_SCRIPT_DIR/mtcxSwReset
    reboot
}

function _showErrorDialog(){
	local title=$1
	local text=$2

	checkLastParam $text "no text given."

    dialog --title "$title" --backtitle "$AREMB_DIALOG_INSTALL_BACKTITLE" --cr-wrap \
                --msgbox "\n$text\n\n\
Press Ok to continue." 10 80
                _receiveResult $tempfile
}

function _showDeinstCfgBootPartDialog(){

	_showPartitionInfoDialog "$AREMB_DIALOG_UNINSTALL_TITLE - Select GPOS partition" "$AREMB_DIALOG_UNINSTALL_BACKTITLE" "\
\nPlease select the GPOS partition: \n \n" "$defaultbootPartitionNr" $BOOT_PART_COUNTER "${BOOT_PART_LIST[@]}"

	if (( ("$retv" == "$DIALOG_NEXT_STATUS") )); then
		let choice=$choice-1
		bootPartitionNr=${BOOT_PART_IDX_LIST[$choice]}
		setPageIdx $UNINST_CFG_AREMB_IDX			#next
	else
		goBack
	fi
}

function _showDeinstCfgARembPartDialog(){
    _showPartitionInfoDialog "$AREMB_DIALOG_UNINSTALL_TITLE - Select partition of ARemb" "$AREMB_DIALOG_UNINSTALL_BACKTITLE" "\
\nPlease select the partition of ARemb: \n \n\
(GPOS on partition: ${partitionComplete[$bootPartitionNr]})" "$defaultExtendedPartitionNr" $EXTENDED_PART_COUNTER "${EXTENDED_PART_LIST[@]}"

	if (( ("$retv" == "$DIALOG_NEXT_STATUS") )); then
		let choice=$choice-1
		ARembPartitionNr=${EXTENDED_PART_IDX_LIST[$choice]}
		setPageIdx $UNINST_CFG_SUMMARY_IDX			#next
	else
		goBack
	fi
}

function _showDeinstCfgSummaryDialog(){
	local arembDevice=${partitionDevice[$ARembPartitionNr]}
	local arembDisk=${partitionDiskNumber[$ARembPartitionNr]}
	local arembDiskDesc=${partitionDeviceDesc[$ARembPartitionNr]}

	local dialogText=

	dialog --title "$AREMB_DIALOG_UNINSTALL_TITLE - Configuration summary" --backtitle "$AREMB_DIALOG_UNINSTALL_BACKTITLE" --cr-wrap \
                --ok-label "$UNINSTALL_LABEL" \
                --extra-button --extra-label "$GO_BACK_LABEL" \
                --no-label "$EXIT_LABEL" \
                --yesno \
"\nPending operations:\n\n\
1. Restore original MBR\n\
2. Uninstall Grub2\n\
3. Uninstall ARemb\n\
4. Uninstall B&R Hypervisor\n\
5. Delete partitions for B&R Hypervisor and ARemb of disk${arembDisk}: ${arembDiskDesc}\n\nExecute?\n \n" 17 120
                _receiveResult $tempfile

    if (( ("$retv" == "$DIALOG_UNINSTALL_STATUS") )); then
		setPageIdx $UNINST_START_IDX				#ok
	else
		goBack
	fi
}

function _uninstall(){
	local bootDevice=${partitionDevice[$bootPartitionNr]}
	local gposPartNr=${partitionDeviceGrubPartNr[$bootPartitionNr]}
	local arembDevice=${partitionDevice[$ARembPartitionNr]}

	if [ -z "$gposPartNr" ]; then
		gposPartNr=1				# partition number where to save the MBR
	fi

	local extPartIdx=
	local prevPartIdx=
	local prevPartNr=
	local mode=

	showUninstProgress "0"
	logWriteUninstallStart

	restoreBootLoader $bootDevice $gposPartNr
	showUninstProgress "30"
	
	deleteExtendedPartition $arembDevice
	showUninstProgress "90"

	logWriteUninstallFinished
	showUninstProgress "100"

	pageIdx=$UNINST_FINISHED_IDX
}

function _legacyMainLoop() {
	while true
	do
		if [ "$partitionsChanged" = "1" ]; then
			partitionsChanged="0"
			_readDrives

			_createARembInstallationCandidates
			_createARembDeinstallationCandidates

			_createPartitionInfoStrings

			_checkIfPartitionsOk

			if [ "$defaultExtendedPartitionNr" = "0" ]; then
    			setPageIdx $MAIN_MENU_INST_IDX
    		else
    			setPageIdx $MAIN_MENU_UNINST_IDX
    		fi
		fi

		case $pageIdx in
		    $MAIN_MENU_INST_IDX)
		                                     _showMainMenuInstallDialog ;;

		    $INST_CFG_AREMB_IDX)
		        if [ "$AREMB_CAND_PART_COUNTER" = "2" ]; then			#index faengt bei 1 an
		            ARembPartitionNr=${AREMB_CAND_PART_IDX_LIST[0]}
		            goBack		# damit man mit goBack wieder zum main menu kommt
		            setPageIdx $INST_CFG_SUMMARY_IDX				#ueberspringen
		        elif [ "$AREMB_CAND_PART_COUNTER" == "1" ];then			#liste leer => kein ARemb candidate vorhanden
					_showErrorDialogWithRestart "$AREMB_DIALOG_INSTALL_TITLE" \
						"There is no disk available to install B&R Hypervisor."
		        else
		            _showInstCfgARembPartDialog
		        fi;;

		    $INST_CFG_SUMMARY_IDX)           _showInstCfgSummaryDialog ;;

		    $INST_START_IDX)                 _install ;;

		    $INST_FINISHED_IDX)              _showRebootDialog \
		                                        "$AREMB_DIALOG_INSTALL_TITLE finished"\
		                                        "Installation successfully completed.";;

		    $MAIN_MENU_UNINST_IDX)           _showMainMenuUninstallDialog ;;

		    $UNINST_CFG_BOOT_IDX)
		        if (( ("$BOOT_PART_COUNTER" == 2) ));then			#index faengt bei 1 an
		            bootPartitionNr=${BOOT_PART_IDX_LIST[0]}
		            goBack		# damit man mit goBack wieder zum main menu kommt
		            setPageIdx $UNINST_CFG_AREMB_IDX			#ueberspringen
		        else
		            _showDeinstCfgBootPartDialog
		        fi;;

		    $UNINST_CFG_AREMB_IDX)
		        if (( ("$EXTENDED_PART_COUNTER" == 2) ));then			#index faengt bei 1 an
	            	ARembPartitionNr=${EXTENDED_PART_IDX_LIST[0]}
	            	goBack		# damit man mit goBack wieder zum main menu kommt
	                setPageIdx $UNINST_CFG_SUMMARY_IDX				#ueberspringen
		        else
		            _showDeinstCfgARembPartDialog
		        fi;;

		    $UNINST_CFG_SUMMARY_IDX)         _showDeinstCfgSummaryDialog ;;

		    $UNINST_START_IDX)               _uninstall ;;

		    $UNINST_FINISHED_IDX)            _showRebootDialog \
		                                         "$AREMB_DIALOG_UNINSTALL_TITLE finished."\
		                                         "Uninstallation successfully completed" ;;

		    $SHOW_PARTITIONS_IDX)            _showPartitionsDialog ;;

		    *)			echo "unhandled pageIdx: $pageIdx"; exit 1;
	   esac
	done
}

function _checkIfPartitionsOk()
{
	if (( $ALL_PART_COUNTER < 2 )); then
	    _showRebootDialog "No CFast found" \
				"Please insert a CFast with an already installed GPOS before installation of B&R Hypervisor."
	fi	
}

function _checkIfUefiOs() {

	local gptInfo=$(parted -l | grep "Partition Table: gpt")
	if [ -n "$gptInfo" ] ; then
		uefiInstall=1
	
if [ -n "$NO_UEFI_SUPPORT" ] ; then
# START: B&R Filesystem: nur weil UEFI noch nicht unterst�tzt werden kann!		
		_showRebootDialog "Error UEFI system" \
				"Currently, B&R Hypervisor cannot be installed on an UEFI system.				
Please install a legacy GPOS and start installation of B&R Hypervisor again."
# ENDE: B&R Filesystem: nur weil UEFI noch nicht unterst�tzt werden kann!
fi

	fi
}

# main logic
#sleep 5			# waiting for 5 seconds

dmesg -n 1		# suppress all messages from the kernel (and its drivers) except panic messages from appearing on the console
loadkeys de
clear

_checkIfUefiOs
# read drives and partitions
partitionsChanged=1

logWriteStart

if  [ "$uefiInstall" = "1" ]; then
	uefiMainLoop
else
	_legacyMainLoop
fi

