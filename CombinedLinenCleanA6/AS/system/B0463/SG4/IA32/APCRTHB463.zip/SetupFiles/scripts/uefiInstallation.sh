#!/bin/bash
# installUefi.sh - perform the UEFI B&R hypervisor installation.

function doUefiInstallation()
{
	local instTitle="$AREMB_DIALOG_INSTALL_TITLE"
	local instMessage="B&R Hypervisor is going to be installed."
	
	showInstProgress "0"
	logWriteInstallStart

	# detect ESP partition
	getEspPartition espDevice espPartNr
	showInstProgress "10"

	# save existing ESP data
	saveEspData $espDevice $espPartNr
	showInstProgress "20"

	#AR:
    # - create partition and format it with FAT
	_createPartition arDevice arPartNr
	showInstProgress "35"

	# - copy Basis AR
	installInitialARemb $arDevice $arPartNr
	showInstProgress "50"

    #hypervisor: create hypervisor configuration
	installHypervisorFiles $arDevice $arPartNr
	showInstProgress "60"

    #grub: install grub in the ESP
	installUefiGrub2 gposName bootline $espDevice $espPartNr
	showInstProgress "80"

    #create hypervisor configuration
    installUefiHypervisorCfg $espDevice $arDevice $arPartNr $gposName "$bootline"
    showInstProgress "90"

	logWriteInstallFinished
	showInstProgress "100"

	setPageIdx $INST_FINISHED_IDX
}

# Returns the device and partition number of the new created and formatted partition for the AR installation.
function _createPartition()
{
	local __arDevice=$1
	local __arPartNr=$2
	local arembDevice=${partitionDevice[$ARembPartitionNr]}
	local arembStartMB=${partitionStart[$ARembPartitionNr]}
	local arembEndMB=${partitionEnd[$ARembPartitionNr]}
	local arembSizeMB=${partitionSize[$ARembPartitionNr]}
	local arembFreeMB=${partitionFree[$ARembPartitionNr]}
	local arembDeviceDesc=${partitionDeviceDesc[$ARembPartitionNr]}

	checkLastParam $__arPartNr "no uuid arPartNr given."

	# search the selected free area on the CFast
	local OIFS=$IFS
	IFS=$'\n'
	local partedOut=$(parted -s $arembDevice unit MB print free)
	local arr=$partedOut
	local string
	local index=0
	local foundIndex=
	for i in $arr
	do
		if [ -n "$i" ]; then
			string=$(echo $i | sed 's/  */ /g' | sed -e 's/^[ \t]*//')   #trim spaces, remove leading spaces
			local currStart=$(echo $string | cut -d ' ' -f 1)
			local currEnd=$(echo $string | cut -d ' ' -f 2)
			local currSize=$(echo $string | cut -d ' ' -f 3)

			if [ "$currStart" = "$arembStartMB" ] && [ "$currEnd" = "$arembEndMB" ] && [ "$currSize" = "${arembSizeMB}MB" ]; then
				foundIndex=$index
				break
			fi
		fi
		let index=index+1
	done

	# search the selected free area on the CFast with sectors
	local partedOut=$(parted -s $arembDevice unit s print free)
	local arr=$partedOut
	local string
	index=0
	for i in $arr
	do
		if [ -n "$i" ]; then
			string=$(echo $i | sed 's/  */ /g' | sed -e 's/^[ \t]*//')   #trim spaces, remove leading spaces
			local currStart=$(echo $string | cut -d ' ' -f 1)
			local currEnd=$(echo $string | cut -d ' ' -f 2)
			local currSize=$(echo $string | cut -d ' ' -f 3)

			if [ "$index" = "$foundIndex" ]; then
				break
			fi
		fi
		let index=index+1
	done
	IFS=$OIFS

	_alignStartSector startSector $currStart
	endSector=$currEnd

	logWriteDebugFunctionCall "parted -s $arembDevice mkpart ARembInstallation fat32 $startSector $endSector"

	_getPartNumber partNumber $arembDevice $startSector $endSector

	logWriteDebugFunctionCall "mkfs -t fat $arembDevice$partNumber"

	logWriteInfo "partition for B&R Hypervisor and ARemb created on disk $arembDeviceDesc"

	eval "${__arDevice}='${arembDevice}'"
	eval "${__arPartNr}='${partNumber}'"
}

function _alignStartSector () {
	local __alignedStartSector=$1
	local startSec=$2
	local alignTo=
	local sectorSize=
	local alignedStartSector=

	checkLastParam $startSec "startSector not given"

	let alignTo=1024*1024		# 1MiB
	let sectorSize=512          # 512 bytes/sector
	let numberOfSectors=$alignTo/$sectorSize

	startSec=${startSec//s/}

	let startSec=$startSec+$numberOfSectors-1
	let alignedStartSector=$startSec/$numberOfSectors*$numberOfSectors
	
	alignedStartSector=$alignedStartSector"s"

	eval "${__alignedStartSector}='${alignedStartSector}'"
}

function _getPartNumber()
{
	local __partNr=$1
	local device=$2
	local startSector=$3
	local endSector=$4

	checkLastParam $endSector "no end sector given."

	# search the new created partition on the CFast with sectors
	local OIFS=$IFS
	IFS=$'\n'
	local partedOut=$(parted -s $arembDevice unit s print free)
	local arr=$partedOut
	local string
	index=0
	for i in $arr
	do
		if [ -n "$i" ]; then
			string=$(echo $i | sed 's/  */ /g' | sed -e 's/^[ \t]*//')   #trim spaces, remove leading spaces
			local currPartNr=$(echo $string | cut -d ' ' -f 1)
			local currStart=$(echo $string | cut -d ' ' -f 2)
			local currEnd=$(echo $string | cut -d ' ' -f 3)

			if [ "$currStart" = "$startSector" ] && [ "$currEnd" = "$endSector" ] ; then
				break
			fi
		fi
		let index=index+1
	done
	IFS=$OIFS

	eval "${__partNr}='${currPartNr}'"
}
