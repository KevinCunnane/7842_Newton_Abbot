#!/bin/bash

###############################################
# Installs Hypervisor on the given partition
#  $1 ... device
#  $2 ... partition number
###############################################
function installInitialARemb(){

	local arembDev=$1
	local arembPartNr=$2

	logWriteDebugFunction "installInitialARemb($arembDev, $arembPartNr)"

	checkLastParam $arembPartNr "no partition number given."

	local arembSysPart=
	mountPartition arembSysPart $arembDev$arembPartNr
	local arembInstDir=$BASEAR_DIR
	local priModulesDir=$arembSysPart/RPSHD/SYSROM

	# copy inital AR files and project modules
	logWriteDebugFunctionCall "cp -f -r $arembInstDir/* $arembSysPart"
	logWriteDebugFunctionCall "mkdir -p $priModulesDir"
	logWriteDebugFunctionCall "mv -f $arembSysPart/*.br $priModulesDir"
	logWriteDebugFunctionCall "touch $arembSysPart/$RTH_TRACE_FILE"

if [ -n "$NO_UEFI_SUPPORT" ] ; then
	# START: B&R Filesystem: nur wegen doppelter Modulablage!
	local secModulesDir=$arembSysPart/RPSHDS/SYSROM
	logWriteDebugFunctionCall "mkdir -p $secModulesDir"
	logWriteDebugFunctionCall "cp -f $priModulesDir/*.br $secModulesDir"
	# ENDE: B&R Filesystem: nur wegen doppelter Modulablage!
fi

	umountDir $arembSysPart

	logWriteInfo "ARemb installed"
}