#!/bin/bash

function installUefiGrub2()
{
	local __gposName=$1
	local __bootline=$2
	local grubDev=$3
	local grubPartNr=$4
	local grubEfiDir=

	logWriteDebugFunction "installUefiGrub2($__gposName, $__bootline, $grubDev, $grubPartNr)"

	checkLastParam $grubPartNr "no GRUB2 partition number given"

	local bootEfiDir="/boot/efi"
	logWriteDebugFunctionCall "mkdir -p $bootEfiDir"
	logWriteDebugFunctionCall "mount $grubDev$grubPartNr $bootEfiDir"
    logWriteDebugFunctionCall "grub-install --target=x86_64-efi --efi-directory=$bootEfiDir --directory=/usr/lib/grub/x86_64-efi --locale-directory=/usr/share/locale --boot-directory=$bootEfiDir/EFI --bootloader-id=ARemb"
	logWriteDebugFunctionCall "umount $bootEfiDir"
	logWriteDebugFunctionCall "rmdir $bootEfiDir"
	logWriteDebugFunctionCall "rmdir /boot"

	mountPartition grubEfiDir $grubDev$grubPartNr
	local mountedGrubCfgPath=$grubEfiDir/EFI/grub/grub.cfg
	_createGrub2Cfg gpos $grubEfiDir $mountedGrubCfgPath

	logWriteFile $mountedGrubCfgPath

	innerBootline=
	if [ "$gpos" = "$LINUX_TAG" ]; then
		getBootlineString innerBootline $mountedGrubCfgPath
		logWriteDebug "linux bootline: $innerBootline"
	fi

	logWriteDebugFunctionCall "umount $grubEfiDir"

	logWriteInfo "Grub2 installed"

	eval "${__gposName}='${gpos}'"
	eval "${__bootline}='${innerBootline}'"
}

function _createGrub2Cfg()
{
	local __innerGpos=$1
	local espDir=$2
	local newGrubCfg=$3
	local grubCfgDev=
	local grubCfgPartNr=
	local grubCfg="-"
	local grubCfgDir=
	local i=
	local detectedGpos=

	checkLastParam $newGrubCfg "no GRUB2 configuration given"

	for (( i=0; i<${#partitionDeviceGrubCfg[@]}; i++ ))
	do
		local grubCfg=${partitionDeviceGrubCfg[$i]}
		if [ "$grubCfg" != "-" ] ; then
			grubCfgDev=${partitionDevice[$i]}
			grubCfgPartNr=${partitionDeviceGrubPartNr[$i]}
			break
		fi
	done

	# valid grub.cfg
	if [ "$grubCfg" != "-" ] ; then
		detectedGpos=$LINUX_TAG
		mountPartition grubCfgDir $grubCfgDev$grubCfgPartNr
		logWriteDebugFunctionCall "cp $grubCfgDir$grubCfg $newGrubCfg"
		logWriteDebugFunctionCall "umountDir $grubCfgDir"
		_addGrub2RthEntryForLinux $newGrubCfg
		_addGrubDefaults $newGrubCfg

	# no grub.cfg => Windows
	else
		detectedGpos=$WINDOWS_TAG
		copyWindowsEfiDir $espDir
		_createWindowsGrubCfg $newGrubCfg
		_addGrubDefaults $newGrubCfg
	fi
	eval "${__innerGpos}='${detectedGpos}'"
}

function _createWindowsGrubCfg()
{
	local winGrubCfg=$1

	checkLastParam $winGrubCfg "no grub.cfg file given."

	logWriteDebug "adding grub2 entry for rth with windows"

	local efiPath="/EFI/Microsoft/Boot"
	local efiFile=$efiPath/$WINDOWS_EFI_FILE
	echo "menuentry \"Windows\" {"                              >> $winGrubCfg
	echo "    search -f   $efiPath/BCD -s"                      >> $winGrubCfg
	echo "    chainloader $efiFile"                             >> $winGrubCfg
	echo "    boot"                                             >> $winGrubCfg
	echo "}"                                                    >> $winGrubCfg
	echo ""                                                     >> $winGrubCfg
	echo "menuentry \"ARemb\" {"                                >> $winGrubCfg
	_addGrub2ArimgEntry   $winGrubCfg
	echo "    search -f   $efiPath/BCD -s"                      >> $winGrubCfg
	echo "    module2     $efiFile $efiFile"                    >> $winGrubCfg
	echo "}"                                                    >> $winGrubCfg
}

function _addGrub2RthEntryForLinux()
{
	local linuxGrubCfg=$1

	checkLastParam $linuxGrubCfg "no grub.cfg file given."

	logWriteDebug "adding grub2 entry for rth with linux"

	local efiFile="/vmlinuz"
	echo "menuentry \"ARemb\" {"                                >> $linuxGrubCfg
	# read neccessary entries for linux
	linuxGrubCfgTmp=$linuxGrubCfg".tmp"
	awk -v GRUB_CFG=$linuxGrubCfgTmp -f ${SHELL_SCRIPT_DIR}/getGrubEntriesForRth.awk $linuxGrubCfg
	cat $linuxGrubCfgTmp                                        >> $linuxGrubCfg
	_addGrub2ArimgEntry   $linuxGrubCfg
	echo "    search -f   $efiFile -s"                          >> $linuxGrubCfg
	echo "    module2     $efiFile        vmlinuz"              >> $linuxGrubCfg
	echo "    module2     /initrd.img     initrd.img"           >> $linuxGrubCfg
	echo "}"                                                    >> $linuxGrubCfg
}

function _addGrub2ArimgEntry()
{
	local arimgGrubCfg=$1

	checkLastParam $arimgGrubCfg "no grub.cfg file given."

	logWriteDebug "adding grub2 entry for ARemb"

	local rthPath="/SYSTEM/RTH"
	local rthFile="$rthPath/rthx86"
	echo "    insmod all_video"                                                        >> $arimgGrubCfg
	echo "    search -f   $rthFile -s"                                                 >> $arimgGrubCfg
	echo "    multiboot2  $rthFile loglevel=$RTH_LOG_LEVEL tracefile=$RTH_TRACE_FILE"  >> $arimgGrubCfg
	echo "    module2     $rthPath/license.txt"                                        >> $arimgGrubCfg
	echo "    module2     $rthPath/ARemb.txt"                                          >> $arimgGrubCfg
	echo "    module2     /arimg          arimg"                                       >> $arimgGrubCfg
}

function _addGrubDefaults()
{
	local grubConfFile=$1

	checkLastParam $grubConfFile "no grub.cfg file given."

	logWriteDebug "adding grub2 defaults"

	echo "set timeout=1" 					>> $grubConfFile
    echo "set default=\"ARemb\""			>> $grubConfFile	
}
