#!/bin/bash

function installUefiHypervisorCfg() {
	local gposDev=$1
	local arDev=$2				# device of AR
	local arPartNr=$3			# partition number of AR system directory
	local gpos=$4
	local bootline="$5"

	logWriteDebugFunction "installUefiHypervisorCfg($gposDev, $arDev, $arPartNr, $gpos, $bootline)"

	checkLastParam $gpos "no gpos name given."

	if [ "$gpos" = "$LINUX_TAG" ] && [ -z "$bootline" ]; then
		logWriteFatal "no bootline given."
	fi

	mountPartition arembSysPart $arDev$arPartNr

	local arembRthDir=$arembSysPart$RTH_DIR

	local out="$arembRthDir/$RTH_CFG.dbg.txt"
	if [ -z "$NO_ACTION" ]; then
		out=$arembRthDir/$RTH_CFG
	fi

	createRthCfgHeader $out
	getPciDriveParameters pciBus pciDevice pciFunction
	let arPartNr=$arPartNr-1
	addRthCfgDriveEntry $gposDev $arDev $arPartNr $out $pciBus $pciDevice $pciFunction
	addRthCfgIoRanges $out
	addRthCfgIRQ $out
	_addRthCfgUefiImagesAndBootline $gpos "$bootline" $out
	addRthCfgOsEntries $gpos $out
	addRthCfgPci $out $pciBus $pciDevice $pciFunction
	addRthCfgShmEntries $out
	addRthCfgSystemEntries $out
	addRthCfgTimeSyncEntries $out

	logWriteFile $out

	umountDir $arembSysPart
}

function _addRthCfgUefiImagesAndBootline()
{
	local gposTag=$1
	local linuxBootLine=$2
	local rthCfgFile=$3

	checkLastParam $rthCfgFile "no RTH config file given."

	logWriteDebug "adding RTH cfg GPOS image entry and bootline"

	echo "[/OS/0/RUNTIME/0]"                                             >> $rthCfgFile
	if [ "$gposTag" = "$WINDOWS_TAG" ]; then
		echo "    \"image_0\"                = \"$WINDOWS_EFI_FILE\""    >> $rthCfgFile
	else
	    echo "    \"bootline\"               = \"$linuxBootLine\""       >> $rthCfgFile
	    echo "    \"image_0\"                = \"vmlinuz\""              >> $rthCfgFile
	    echo "    \"image_1\"                = \"initrd.img\""           >> $rthCfgFile
	fi
    echo ""                                                              >> $rthCfgFile
}