#!/bin/bash

function _showProgressDialog()
{
	local percent=$1
	local title=$2
	local message=$3
	
	checkLastParam "$message" "no progress message given."
	
	echo "$percent" | dialog --title "$title" --gauge "$message\n\nPlease wait..." 10 70 0
}

function showInstProgress()
{
	local percent=$1
	checkLastParam "$percent" "no percent value given."
	_showProgressDialog "$percent" "$AREMB_DIALOG_INSTALL_TITLE" "\nB&R Hypervisor is going to be installed."
}

function showUninstProgress()
{
	local percent=$1
	checkLastParam "$percent" "no percent value given."
	_showProgressDialog "$percent" "$AREMB_DIALOG_UNINSTALL_TITLE" "\nB&R Hypervisor is going to be uninstalled."
}