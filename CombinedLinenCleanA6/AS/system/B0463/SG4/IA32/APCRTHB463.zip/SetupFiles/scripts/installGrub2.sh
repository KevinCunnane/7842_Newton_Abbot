#!/bin/bash

function _addWindowsGrub2MenuEntry() {
	local grubCfgFile=$1

	checkLastParam $grubCfgFile "no grub config file given. _addWindowsGrub2MenuEntry($grubCfgFile)"

	if [ -n "$NO_ACTION" ]; then
		grubCfgFile=/dev/stdout
	fi

	logWriteDebug "adding Windows Grub2 menuentry into $grubCfgFile"

	echo "menuentry \"Windows\" {" 					>> $grubCfgFile
	echo "	insmod ntfs" 							>> $grubCfgFile
	echo "	set root=(hd0,msdos1)" 					>> $grubCfgFile
	echo "	ntldr /bootmgr" 						>> $grubCfgFile
	echo "}" 										>> $grubCfgFile
	echo "" 										>> $grubCfgFile
}

function _addWindowsARembGrub2MenuEntry() {
	local grubCfgFile=$1
	local arembRoot=$2

	checkLastParam $arembRoot "no partition number given. _addWindowsARembGrub2MenuEntry($grubCfgFile, $arembRoot)"

	if [ -n "$NO_ACTION" ]; then
		grubCfgFile=/dev/stdout
	fi

	logWriteDebug "adding ARemb (root: $arembRoot) into $grubCfgFile."

	echo "menuentry \"ARemb\"  {" 															>> $grubCfgFile
	echo "	search -f $RTH_DIR/rthx86 -s"															>> $grubCfgFile
	echo "	multiboot $RTH_DIR/rthx86 loglevel=$RTH_LOG_LEVEL tracefile=$RTH_TRACE_FILE"	>> $grubCfgFile
	echo "	module    $RTH_DIR/license.txt" 												>> $grubCfgFile
    echo "	module    $RTH_DIR/ARemb.txt"													>> $grubCfgFile
	echo "	module    /arimg    arimg"														>> $grubCfgFile
	echo "}" 																				>> $grubCfgFile
}

function _addLinuxARembGrub2MenuEntry() {
	local grubCfgFile=$1
	local gposRoot=$2
	local arembRoot=$3

	checkLastParam $arembPartNr "no partition number given. _addLinuxARembGrub2MenuEntry($grubCfgFile, $gposRoot, $arembRoot)"

	logWriteDebug "adding grub2 entry for ARemb on linux"

	#get Linuz image and initrd.img name
	local grubVmlinuz=
	local grubInitRd=
	grubVmlinuz=$(grep "linux" $grubCfgFile | grep -i "vmlinuz" | sed 's/\s/ /g' | sed 's/  / /g' | cut -d ' ' -f 3 | head -n 1)
	grubInitRd=$(grep "initrd" $grubCfgFile | sed 's/\s/ /g' | sed 's/  / /g' | cut -d ' ' -f 3 | head -n 1)

	if [ -n "$NO_ACTION" ]; then
		grubCfgFile=/dev/stdout
	fi
	echo "menuentry \"ARemb\" {" 															>> $grubCfgFile
	echo "	search -f $RTH_DIR/rthx86 -s"													>> $grubCfgFile
	echo "	multiboot $RTH_DIR/rthx86 loglevel=$RTH_LOG_LEVEL tracefile=$RTH_TRACE_FILE"	>> $grubCfgFile
	echo "	module    $RTH_DIR/license.txt"					 								>> $grubCfgFile
	echo "	module    $RTH_DIR/ARemb.txt" 													>> $grubCfgFile
	echo "	module    /arimg    arimg"														>> $grubCfgFile
	echo "	search -f $grubVmlinuz -s"														>> $grubCfgFile
	echo "	module    $grubVmlinuz   vmlinuz"												>> $grubCfgFile
	echo "	module    $grubInitRd    initrd.img"											>> $grubCfgFile
	echo "}" 																				>> $grubCfgFile
	echo "" 																				>> $grubCfgFile
}

function _addDefaultGrub2Entry() {
	local grubCfgFile=$1
	local defaultEntry=$2
	local timeout=$3

	checkLastParam $timeout "no timeout given. _addDefaultGrub2Entry($grubCfgFile, $defaultEntry, $timeout)"

	if [ -n "$NO_ACTION" ]; then
		grubCfgFile=/dev/stdout
	fi
	
	logWriteDebug "adding grub2 default entries"

	echo "set timeout=$timeout" 					>> $grubCfgFile
	echo "set default=\"$defaultEntry\""			>> $grubCfgFile
}

function _getDiskNumberOfDevice(){
	local __num=$1
	local dev=$2

	checkLastParam $dev "no device given. _getDiskNumberOfDevice($__num, $dev)"

	local letter=${dev:7}
	local num="0"
	if [ "$letter" = "a" ]; then
		num="0"
	elif [ "$letter" = "b" ]; then
		num="1"
	elif [ "$letter" = "c" ]; then
		num="2"
	elif [ "$letter" = "d" ]; then
		num="3"
	fi
	eval "${__num}='${num}'"
}

function _getRootForGrubEntry(){
	local __root=$1
	local dev=$2
	local partNr=$3

	checkLastParam $partNr "no partNr given. _getRootForGrubEntry($__root, $dev, $partNr)"

	local numb=
	_getDiskNumberOfDevice numb $dev
	local root="(hd$numb,msdos$partNr)"

	eval "${__root}='${root}'"
}

function _installGrub2(){
	local device=$1
	local origGrubCfgFile=$2
	local gposDevice=$3
	local gposPartNr=$4
	local gpos=$5
	local arembDevice=$6
	local arembPartNr=$7

	checkLastParam $arembPartNr "no partition number of ARemb given."

	mountPartition grubCfgDir $arembDevice$arembPartNr

	logWriteDebugFunctionCall "mkdir -p $grubCfgDir$GRUB_DIR"

	# install grub
	logWriteDebugFunctionCall "grub-install --boot-directory=$grubCfgDir$AR_SYSTEM_DIR --directory=/Setup/grub/i386-pc --locale-directory=$SETUP_DIR/grub/locale $device"

	#create new grub.cfg
	local GrubCfgFile=$grubCfgDir$GRUB_DIR/grub.cfg

    _getRootForGrubEntry gposRoot $gposDevice $gposPartNr
    _getRootForGrubEntry arembRoot $arembDevice $arembPartNr

	USE_GRUB_MKCONFIG=
	if [ "$USE_GRUB_MKCONFIG" = "Y" ]; then
		logWriteDebugFunctionCall "mount $arembDevice$arembPartNr /"
		logWriteDebugFunctionCall "mkdir -p /boot"
		logWriteDebugFunctionCall "mount --bind $grubCfgDir$GRUB_DIR /boot"
		for tool in basename cut find head id readlink tail; do
			logWriteDebugFunctionCall "ln -s /bin/busybox /bin/$tool"
		done
		logWriteDebugFunctionCall "grub-mkconfig -o $GrubCfgFile"
		logWriteDebugFunctionCall "umount /boot"
		logWriteDebugFunctionCall "umount /"

		#TODO TODO TODO
		# wenn grub-mkconfig funktioniert sollten diese zeilen geloescht werden
		# und durch grub2 40_custom script ersetzt werden
		if [ "$gpos" = "$WINDOWS_TAG" ]; then
			_addWindowsGrub2MenuEntry $GrubCfgFile
			_addWindowsARembGrub2MenuEntry $GrubCfgFile $arembRoot
		else
			_addLinuxARembGrub2MenuEntry $GrubCfgFile $gposRoot $arembRoot
		fi
		_addDefaultGrub2Entry $GrubCfgFile "ARemb" "1"

	else
		if [ "$gpos" = "$WINDOWS_TAG" ]; then
			_addWindowsGrub2MenuEntry $GrubCfgFile
			_addWindowsARembGrub2MenuEntry $GrubCfgFile $arembRoot

		else
			#original grub.cfg
			logWriteDebugFunctionCall "cp $origGrubCfgFile $GrubCfgFile"
			_addLinuxARembGrub2MenuEntry $GrubCfgFile $gposRoot $arembRoot
		fi
		_addDefaultGrub2Entry $GrubCfgFile "ARemb" "1"
	fi

	logWriteFile $GrubCfgFile

	umountDir $grubCfgDir

	logWriteInfo "Grub2 installed into MBR"
}

###############################################
# Installs Grub2 on the given partition
#  $1 ... device
#  $2 ... partition number
#  $3 ... GPOS: "Windows" or "Linux"
###############################################
function installGrub2(){
	local grubDev=$1
	local grubPartNr=$2
	local gposDevice=$3
	local gposPartNr=$4
	local gpos=$5
	local grubCfg=$6
	local arembDevice=$7
	local arembPartNr=$8

	logWriteDebugFunction "installGrub2($grubDev, $grubPartNr, $gposDevice, $gposPartNr, $gpos, $grubCfg, $arembDevice, $arembPartNr)"

	checkLastParam $arembPartNr "no partition number of ARemb given."

	# mount GPOS partition
	local GrubDir=

	mountPartition GrubDir $grubDev$grubPartNr
	if [ "$?" != "0" ]; then
		logWriteError "Installation of grub2 failed" "The partition for the grub2 boot loader could not be mounted."
	fi

	local origGrubCfg=$GrubDir$grubCfg
	_installGrub2 $grubDev $origGrubCfg $gposDevice $gposPartNr $gpos $arembDevice $arembPartNr

	umountDir $GrubDir
	return $errorCode
}

function getBootLine() {
	local __bootline=$1
	local grubDev=$2
	local grubPartNr=$3
	local gpos=$4
	local grubCfg=$5

	logWriteDebugFunction "getBootLine($__bootline, $grubDev, $grubPartNr, $gpos, $grubCfg)"

	checkLastParam $grubCfg "no grub cfg given."

	bootline="-"
	if [ "$gpos" != "$WINDOWS_TAG" ]; then
		local arembSysPart=
		local grubPart=
		mountPartition grubPart $grubDev$grubPartNr

		getBootlineString bootline $grubPart$grubCfg

		umountDir $grubPart
	fi

	eval "$__bootline='$bootline'"
}

function getBootlineString()
{
	local __bl=$1
	local grubCfgPath=$2
	local bl=

	logWriteDebugFunction "getBootlineString($__bl, $grubCfgPath)"

	checkLastParam $grubCfgPath "no grub cfg given."

	bl=$(grep "linux" $grubCfgPath | grep -i "vmlinuz" | sed 's/\s/ /g' | sed 's/  / /g' | cut -d ' ' -f 4- | head -n 1)
	logWriteDebug "bootline: $bl"
	eval "$__bl='$bl'"
}

