#!/bin/bash
# uefiUninstallation.sh - perform the UEFI B&R hypervisor uninstallation.

function doUefiUninstallation()
{
	showUninstProgress "0"
	logWriteUninstallStart

	# detect ESP partition
	getEspPartition espDevice espPartNr
	showUninstProgress "20"
		
	# restore ESP data
	restoreEspData $espDevice $espPartNr
	showUninstProgress "50"
	
    #AR:
    # - delete partition
	_removeARembPartition
	showUninstProgress "80"

	logWriteUninstallFinished
	showUninstProgress "100"
	
	setPageIdx $UNINST_FINISHED_IDX
}

function _checkEspPartition()
{
	local freeDir=
	mountPartition freeDir $devicePartNr
}

# Removes the ARemb partition.
function _removeARembPartition()
{
	local arembDevice=${partitionDevice[$ARembPartitionNr]}
	local arembPartNr=${partitionPartNr[$ARembPartitionNr]}
	local arembDevDesc=${partitionDeviceDesc[$ARembPartitionNr]}

	logWriteDebugFunctionCall "parted -s $arembDevice rm $arembPartNr"
		
	logWriteInfo "ARemb uninstalled"
	logWriteInfo "B&R hypervisor uninstalled"
	logWriteInfo "Partition for B&R hypervisor and ARemb on disk $arembDevDesc deleted"
}
