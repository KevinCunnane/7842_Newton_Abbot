#!/bin/bash
# handleExtendedPartition.sh - Creates or deletes an extended partition on the given device 
# Author: Peter Maier
# Date: 13/Jun/2016

BACKUP_DIR="B_R-B_A_C_K_U_P"

#####################################################
# Creates an extended partition on the given device
#  $1 ... device
# returns EXTENDED_PARTITION_START_SECTOR ... start sector of the created extended partition
# returns EXTENDED_PARTITION_END_SECTOR ... end sector of the created extended partition
#####################################################
function createExtendedPartition(){
	local device=$1
	local logSectSize=$2

	logWriteDebugFunction "createExtendedPartition($device, $logSectSize)"

	checkLastParam $logSectSize "no logical sector size given."

	# read partition info
	OIFS=$IFS
	IFS=$'\n'
	partedOutput=$(parted -s $device unit s print free | sed 's/  */ /g')
	arr=$partedOutput
	for i in $arr
	do
		if [[ "$i" =~ "$device" ]]; then
			sectors=$(echo $i | cut -d ':' -f 2)
		fi
		lastStartSector=$(echo $i | cut -d ' ' -f 2)
		lastEndSector=$(echo $i | cut -d ' ' -f 3)
		lastSectors=$(echo $i | cut -d ' ' -f 4)
	done
	IFS=$OIFS

	startSectorForCalc=${lastStartSector//s/}		# first sector of free space
	endSectorForCalc=${lastEndSector//s/}			# last sector of free space

	#align to 1MB
	let alignTo=1024*1024		# 1MiB
	let numberOfSectors=$alignTo/$logSectSize
	let startSectorForCalc=($startSectorForCalc+$numberOfSectors)/$numberOfSectors*$numberOfSectors

	logWriteDebugFunctionCall "parted -s $device mkpart extended ${startSectorForCalc}s ${endSectorForCalc}s"
}

function _alignTo1MiB () {
	local __alignedSector=$1
	local device=$2
	local sector=$3
	local roundUp=$4
	local alignTo=

	checkLastParam $roundUp "round up not given"

	let alignTo=1024*1024		# 1MiB

# read partition info
	OIFS=$IFS
	IFS=$'\n'
	partedOutput=$(parted -s $device unit s print free | sed 's/  */ /g')
	arr=$partedOutput
	nextIsFreeSpace=
	sectorSize=
	for i in $arr
	do
		# read sector size
		if [ -z "$sectorSize" ] ; then
			if [[ "$i" =~ "(logical/physical)" ]]; then
				sectorSize=$(echo $i | cut -d ':' -f 2)
				sectorSize=$(echo $sectorSize | cut -d '/' -f 1)
				sectorSize=${sectorSize// /}		#remove ' '
				sectorSize=${sectorSize//B/}		#remove 'B'
			fi
		fi
	done
	IFS=$OIFS

	let numberOfSectors=$alignTo/$sectorSize

	if [ "$roundUp" = "1" ]; then
		let sector=$sector+$numberOfSectors-1
	fi
	let alignedSector=$sector/$numberOfSectors*$numberOfSectors
	eval $__alignedSector=$alignedSector
}

#####################################################
# Gets the free sectors of the extended partition on the given device.
# The sectors are already aligned to 1MiB.
#  $1 ... return value: startSector
#  $2 ... return value: endSector
#  $3 ... device
#####################################################
function _getFreeSectorsOfExtendedPartition(){
	local __startSector=$1
	local __endSector=$2
	local device=$3

	checkLastParam $device "no device given."

	# read partition info
	OIFS=$IFS
	IFS=$'\n'
	local partedOutput=$(parted -s $device unit s print free | sed 's/  */ /g')
	local arr=$partedOutput
	local nextIsFreeSpace=
	local startSector=
	local endSector=
	for i in $arr
	do
		if [ -n "$nextIsFreeSpace" ]; then
			startSector=$(echo $i | cut -d ' ' -f 2)
			endSector=$(echo $i | cut -d ' ' -f 3)
			partFree=$(echo $i | cut -d ' ' -f 5)
									
			if [[ "$partFree" =~ "Free" ]]; then
				startSector=${startSector//s/}
				_alignTo1MiB startSectorAligned $device $startSector "1"
				endSector=${endSector//s/}
				break;
			fi
		fi
		currPartNr=
		partType=$(echo $i | cut -d ' ' -f 6)
		
		if [ "$partType" = "extended" ]; then
			nextIsFreeSpace=1
		fi
	done
	IFS=$OIFS

	# faking values
	if [ -n "$NO_ACTION" ]; then
		let startSectorAligned=1024*1024
		endSector=4*1024*1024
	fi

	eval $__startSector=$startSectorAligned
	eval $__endSector=$endSector
}

#####################################################
# Deletes the extended partition on the given device
#  $1 ... device
#####################################################
function deleteExtendedPartition(){
	local device=$1

	logWriteDebugFunction "deleteExtendedPartition($device)"
	
	checkLastParam $device "no device given. deleteExtendedPartition($device)"

	# read partition info
	OIFS=$IFS
	IFS=$'\n'
	partedOutput=$(parted -s $device unit s print | sed 's/  */ /g')
	arr=$partedOutput
	for i in $arr
	do
		currPartNr=
		partType=$(echo $i | cut -d ' ' -f 6)
		if [ "$partType" = "extended" ]; then
			currPartNr=$(echo $i | cut -d ' ' -f 2)
			break;
		fi
	done
	IFS=$OIFS

	if [ -n "$currPartNr" ]; then
		logWriteDebugFunctionCall "parted -s $device rm ${currPartNr}"
		logWriteInfo "Grub2 uninstalled"
		logWriteInfo "ARemb uninstalled"
		logWriteInfo "B&R Hypervisor uninstalled"
		logWriteInfo "Partitions for B&R Hypervisor and ARemb deleted"
	fi
}

function getExtendedPartitionNumber() {
	local __extPartNr=$1
	local device=$2
	local partNr=

	logWriteDebugFunction "getExtendedPartitionNumber($__extPartNr, $device)"

	checkLastParam $device "no device given."

	# read partition info
	partNr=$(parted -s $device print | grep "extended" | sed 's/  */ /g' | cut -d ' ' -f 2)

	eval "$__extPartNr='$partNr'"
}

###############################################################
# Gets the size of the extended partition on the given device
#  $1 ... device
#  returns EXTENDED_PARTITION_SIZE_IN_MB ... partition size in MB
###############################################################
function getExtendedPartitionSize(){
	local __extendedSizeInMb=$1
	local device=$2

	logWriteDebugFunction "getExtendedPartitionSize($__extendedSizeInMb, $device)"

	checkLastParam $device "no device given."

	# read partition info
	OIFS=$IFS
	IFS=$'\n'
	partedOutput=$(parted -s $device unit MB print | sed 's/  */ /g')
	arr=$partedOutput
	for i in $arr
	do
		partSize=
		partType=$(echo $i | cut -d ' ' -f 6)
		if [ "$partType" = "extended" ]; then
			partSize=$(echo $i | cut -d ' ' -f 5)
			break;
		fi
	done
	IFS=$OIFS

	extPartSize=0
	if [ -n "$partSize" ]; then
		extPartSize=${partSize//MB/}		# return value (remove MB)
		extPartSize=$(echo $extPartSize | cut -d '.' -f 1)	# remove fractional digits
	fi
	eval $__extendedSizeInMb=$extPartSize
}

###############################################################################
# Gets the preceeding partition of the extended partition on the given device
#  $1 ... device
#  returns NUMBER_OF_PRECEEDING_PARTITION_OF_EXTENDED_PARTITION ... partition number of the preceeding partition of the extended partition
###############################################################################
function getPreceedingPartitionNrOfExtendedPartition(){
	local __preceedingPartNr=$1
	local device=$2

	logWriteDebugFunction "getPreceedingPartitionNrOfExtendedPartition($__preceedingPartNr, $device)"

	checkLastParam $device "no device given."

	# read partition info
	OIFS=$IFS
	IFS=$'\n'
	local partedOutput=$(parted -s $device print | sed 's/  */ /g')
	local arr=$partedOutput
	local precPartNr=
	for i in $arr
	do
		partSize=
		partNr=$(echo $i | cut -d ' ' -f 2)
		partType=$(echo $i | cut -d ' ' -f 6)
		if [ "$partType" = "extended" ]; then
			precPartNr=$prevPartNr
			break;
		fi
		if [ -n "$partNr" ] ; then
			prevPartNr=$partNr
		fi
	done
	IFS=$OIFS

	eval $__preceedingPartNr=$precPartNr
}

################################################################################################
# Creates two partitions into the extended partition on the given device
# the second partition is a backup partition with fixed size
#  $1 ... partition number of the ARemb partition
#  $2 ... device
################################################################################################
function createARembPartitions(){
	local __ARembPartitionNumber=$1
	local device=$2
	local logSectSize=$3

	logWriteDebugFunction "createARembPartitions($__ARembPartitionNumber, $device, $logSectSize)"

	let BACKUP_PARTITION_SIZE_IN_BYTES=10*1024*1024

	checkLastParam $logSectSize "no logSectSize given."

	local extStartSector=
	local extEndSector=
	_getFreeSectorsOfExtendedPartition extStartSector extEndSector $device

	let backupPartSectors=BACKUP_PARTITION_SIZE_IN_BYTES/$logSectSize
	let backupPartStart=$extEndSector-$backupPartSectors
	let systemPartStart=$extStartSector

	_alignTo1MiB systemPartStart $device $systemPartStart "1"
	_alignTo1MiB backupPartStart $device $backupPartStart "1"

	# it seems that there must be a free sector between two logical partitions 
	let systemPartEnd=$backupPartStart-2
	backupPartEnd=$extEndSector

	systemPartStart=$systemPartStart"s"
	backupPartStart=$backupPartStart"s"
	systemPartEnd=$systemPartEnd"s"
	backupPartEnd=$backupPartEnd"s"

	logWriteDebugFunctionCall "parted -s $device mkpart logical fat32 $systemPartStart $systemPartEnd"
	logWriteDebugFunctionCall "parted -s $device mkpart logical fat32 $backupPartStart $backupPartEnd"

	# format new logical partitions
	OIFS=$IFS
	IFS=$'\n'
	partedOutput=$(parted -s $device unit MB print | sed 's/  */ /g')
	arr=$partedOutput
	local arembPartNr=
	local j=0
	for i in $arr
	do
		partNr=$(echo $i | cut -d ' ' -f 2)
		partType=$(echo $i | cut -d ' ' -f 6)
		if [ "$partType" = "logical" ]; then
			if [ -z "$arembPartNr" ]; then
				arembPartNr=$partNr
			fi
			logWriteDebugFunctionCall "mkfs -t fat $device$partNr"
			if [ "$j" = "0" ]; then
				logWriteDebugFunctionCall "dosfslabel $device$partNr SYSTEM"
			else
				logWriteDebugFunctionCall "dosfslabel $device$partNr BACKUP"
				local backupDir
				mountPartition backupDir $device$partNr
				logWriteDebugFunctionCall "mkdir $backupDir/$BACKUP_DIR"
				umountDir $backupDir
			fi
			let j=$j+1
		fi
	done
	IFS=$OIFS
	if [ "$j" != "0" ]; then
		logWriteInfo "Partitions for B&R Hypervisor and ARemb created"
	fi
	eval $__ARembPartitionNumber=$arembPartNr
}
