#!/bin/bash

###############################################
# Installs Hypervisor on the given partition
#  $1 ... device
#  $2 ... partition number
###############################################
function installInitialARemb(){

	local arembDev=$1
	local arembPartNr=1
	DEBUG_MESSAGE "installing initial ARemb files on partition $arembDev$arembPartNr"

	if [ -z "$arembDev" ]; then
		printError "no device given."
	fi

	local arembSysPart=
	mountPartition arembSysPart $arembDev$arembPartNr
	local arembInstDir=$BASEAR_DIR
	local priModulesDir=$arembSysPart/RPSHD/SYSROM
	local secModulesDir=$arembSysPart/RPSHDS/SYSROM

	# copy inital AR files and project modules
	
	DEBUG_MESSAGE "cp -f -r $arembInstDir/* $arembSysPart"
	if [ -z "$NO_ACTION" ]; then
		cp -f -r $arembInstDir/* $arembSysPart
	fi
	
	DEBUG_MESSAGE "mkdir -p $priModulesDir"
	if [ -z "$NO_ACTION" ]; then
		mkdir -p $priModulesDir
	fi
	
	DEBUG_MESSAGE "mkdir -p $secModulesDir"
	if [ -z "$NO_ACTION" ]; then
		mkdir -p $secModulesDir
	fi
	
	DEBUG_MESSAGE "cp -f $arembSysPart/*.br $priModulesDir"
	if [ -z "$NO_ACTION" ]; then
		cp -f $arembSysPart/*.br $priModulesDir
	fi
	
	DEBUG_MESSAGE "mv -f $arembSysPart/*.br $secModulesDir"
	if [ -z "$NO_ACTION" ]; then
		mv -f $arembSysPart/*.br $secModulesDir
	fi
	
	umountDir $arembSysPart
}