#!/bin/bash
# uefiUninstallation.sh - perform the UEFI B&R hypervisor uninstallation.

function doUefiUninstallation()
{
	showUninstProgress "0"
	logWriteUninstallStart

	# detect ESP partition
	getEspPartition espDevice espPartNr
	showUninstProgress "20"
		
	# restore ESP data
	restoreEspData $espDevice $espPartNr
	showUninstProgress "50"
	
    #AR:
    # - delete partition
	_removeARembPartitions
	showUninstProgress "80"

	logWriteUninstallFinished
	showUninstProgress "100"
	
	setPageIdx $UNINST_FINISHED_IDX
}

# Removes the ARemb partition(s).
function _removeARembPartitions()
{
	local arembDevice=${partitionDevice[$ARembPartitionNr]}
	local arembDevDesc=${partitionDeviceDesc[$ARembPartitionNr]}

	# search the new created partition on the CFast with sectors
	local OIFS=$IFS
	IFS=$'\n'
	local partedOut=$(parted -s $arembDevice print | grep "$AREMB_INSTALLATION_PARTITION_NAME")
	local arr=$partedOut
	local string
	index=0
	for i in $arr
	do
		if [ -n "$i" ]; then
			string=$(echo $i | sed 's/  */ /g' | sed -e 's/^[ \t]*//')   #trim spaces, remove leading spaces
			local currPartNr=$(echo $string | cut -d ' ' -f 1)

			logWriteDebugFunctionCall "parted -s $arembDevice rm $currPartNr"			
		fi
		let index=index+1
	done
	IFS=$OIFS
		
	logWriteInfo "ARemb uninstalled"
	logWriteInfo "B&R Hypervisor uninstalled"
	logWriteInfo "Partition(s) for B&R Hypervisor and ARemb on disk $arembDevDesc deleted"
}
