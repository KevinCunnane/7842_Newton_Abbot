#!/bin/bash

UEFI_AREMB_BOOT_ENTRY_NAME="BR\ Hypervisor"
GRUB_AREMB_BOOT_ENTRY_NAME="BR Hypervisor"

function installUefiGrub2()
{
	local __gposName=$1
	local __bootline=$2
	local efiPartMarkerFilePath="/EFI/grub/$3"
	local grubDev=$4
	local grubPartNr=$5
	local grubEfiDir=
	
	logWriteDebugFunction "installUefiGrub2($__gposName, $__bootline, $efiPartMarkerFilePath, $grubDev, $grubPartNr)"

	checkLastParam $grubPartNr "no GRUB2 partition number given"

	local bootEfiDir="/boot/efi"
	logWriteDebugFunctionCall "mkdir -p $bootEfiDir"
	logWriteDebugFunctionCall "mount $grubDev$grubPartNr $bootEfiDir"

	local libModulesDir=/lib/modules/
	local usedKernel=$(ls $libModulesDir)
	local neededKernel=$(uname -r)
	logWriteDebug "used kernel: $usedKernel"
	logWriteDebug "needed kernel: $neededKernel"
	if [ "$neededKernel" != "usedKernel" ] ; then
		logWriteDebugFunctionCall "ln -s $libModulesDir$usedKernel $libModulesDir$neededKernel"
	fi

    logWriteDebugFunctionCall "grub-install --target=x86_64-efi --efi-directory=$bootEfiDir --directory=/usr/lib/grub/x86_64-efi --locale-directory=/usr/share/locale --boot-directory=$bootEfiDir/EFI --bootloader-id=$UEFI_AREMB_BOOT_ENTRY_NAME"
    local newBootNum=$(efibootmgr | grep "BootOrder:" | cut -d ' ' -f 2 | cut -d',' -f 1)
    local newBootDesc=$(efibootmgr | grep "Boot$newBootNum" | cut -d ' ' -f 2- )
    
    getEspPartition espDevice espPartNr
    getAhciPortFromDevice ahciPort $espDevice
    
    logWriteAddUninstallCmd "delDir $ahciPort $espPartNr \"/EFI/grub\""
    logWriteAddUninstallCmd "delDir $ahciPort $espPartNr \"/EFI/$GRUB_AREMB_BOOT_ENTRY_NAME\""
    logWriteAddUninstallCmd "delEfiBootEntry \"$newBootDesc\""
	# Mark the EFI-Partition where the BR Hyp GRUB is installed by storing a .efi file with an unique name
	# This file will not be loaded, it is only searched by the RTS-Hyp to itdentify the right EFI-Partition, but it must be a valid EFI executable.
	# The filename must match with the Hyp-config parameter "image_0" (under [/OS/0/RUNTIME/0])
	logWriteDebugFunctionCall "cp $bootEfiDir/EFI/$UEFI_AREMB_BOOT_ENTRY_NAME/grubx64.efi $bootEfiDir$efiPartMarkerFilePath"
	logWriteDebugFunctionCall "umount $bootEfiDir"
	logWriteDebugFunctionCall "rmdir $bootEfiDir"
	logWriteDebugFunctionCall "rmdir /boot"

	mountPartition grubEfiDir $grubDev$grubPartNr
	local mountedGrubCfgPath=$grubEfiDir/EFI/grub/grub.cfg
	_createGrub2Cfg gpos $grubEfiDir $mountedGrubCfgPath $efiPartMarkerFilePath

	logWriteFile $mountedGrubCfgPath

	innerBootline=
	if [ "$gpos" = "$LINUX_TAG" ]; then
		getBootlineString innerBootline $mountedGrubCfgPath
		logWriteDebug "linux bootline: $innerBootline"
	fi

	logWriteDebugFunctionCall "umount $grubEfiDir"

	logWriteInfo "Grub2 installed"

	eval "${__gposName}='${gpos}'"
	eval "${__bootline}='${innerBootline}'"
}

function _createGrub2Cfg()
{
	local __innerGpos=$1
	local espDir=$2
	local newGrubCfg=$3
	local efiPartMarkerFilePath=$4
	local grubCfgDev=
	local grubCfgPartNr=
	local grubCfg="-"
	local grubCfgDir=
	local i=
	local detectedGpos=

	logWriteDebugFunction "_createGrub2Cfg($__innerGpos, $espDir, $newGrubCfg, $efiPartMarkerFilePath)"

	checkLastParam $efiPartMarkerFilePath "no efi marker filename given"

	for (( i=0; i<${#partitionDeviceGrubCfg[@]}; i++ ))
	do
		local grubCfg=${partitionDeviceGrubCfg[$i]}
		if [ "$grubCfg" != "-" ] ; then
			grubCfgDev=${partitionDevice[$i]}
			grubCfgPartNr=${partitionDeviceGrubPartNr[$i]}
			break
		fi
	done

	# valid grub.cfg
	if [ "$grubCfg" != "-" ] ; then
		detectedGpos=$LINUX_TAG
		mountPartition grubCfgDir $grubCfgDev$grubCfgPartNr
		logWriteDebugFunctionCall "cp $grubCfgDir$grubCfg $newGrubCfg"
		logWriteDebugFunctionCall "umountDir $grubCfgDir"
		_addGrub2RthEntryForLinux $newGrubCfg $efiPartMarkerFilePath
		_addGrubDefaults $newGrubCfg

	# no grub.cfg => Windows
	else
		detectedGpos=$WINDOWS_TAG
		copyWindowsEfiDir $espDir
		_createWindowsGrubCfg $newGrubCfg $efiPartMarkerFilePath
		_addGrubDefaults $newGrubCfg
	fi
	eval "${__innerGpos}='${detectedGpos}'"
}

function _createWindowsGrubCfg()
{
	local winGrubCfg=$1
	local efiPartMarkerFilePath=$2

	checkLastParam $efiPartMarkerFilePath "no efi marker filename given"

	logWriteDebug "adding grub2 entry for rth with windows"

	local efiFile="/EFI/Microsoft/Boot/$WINDOWS_EFI_FILE"
	
	_addDiskDetectMethod $winGrubCfg $efiPartMarkerFilePath
	
	echo "menuentry \"Windows\" {"                              >> $winGrubCfg
	echo "    root=\$efiPart"				                    >> $winGrubCfg
	echo "    chainloader $efiFile"                             >> $winGrubCfg
	echo "    boot"                                             >> $winGrubCfg
	echo "}"                                                    >> $winGrubCfg
	echo ""                                                     >> $winGrubCfg
	echo "menuentry \"$GRUB_AREMB_BOOT_ENTRY_NAME\" {"          >> $winGrubCfg
	_addGrub2ArimgEntry $winGrubCfg
	echo "    root=\$efiPart"							        >> $winGrubCfg
	echo "    module2     $efiFile $efiPartMarkerFilePath"     >> $winGrubCfg
	echo "}"                                                    >> $winGrubCfg
}

function _addGrub2RthEntryForLinux()
{
	local linuxGrubCfg=$1
	local efiPartMarkerFilePath=$2
	
	checkLastParam $linuxGrubCfg "no grub.cfg file given."

	logWriteDebug "adding grub2 entry for rth with linux"

	local linuxKernelImageLnk="/boot/vmlinuz.lnk"
	local linuxFileSystemLnk="/boot/initramfs.lnk"
	local linuxImage2="/boot/$LINUX_IMAGE_2"
	
	_addDiskDetectMethod $linuxGrubCfg $efiPartMarkerFilePath
		
	echo "menuentry \"$GRUB_AREMB_BOOT_ENTRY_NAME\" {"          >> $linuxGrubCfg
	# read neccessary entries for linux
	linuxGrubCfgTmp=$linuxGrubCfg".tmp"
	awk -v GRUB_CFG=$linuxGrubCfgTmp -f ${SHELL_SCRIPT_DIR}/getGrubEntriesForRth.awk $linuxGrubCfg
	cat $linuxGrubCfgTmp                                        >> $linuxGrubCfg
	_addGrub2ArimgEntry   $linuxGrubCfg
	echo "    search -f   $linuxKernelImageLnk -s"                           >> $linuxGrubCfg
	echo "    module2     $linuxKernelImageLnk        $LINUX_VMLINUZ_NAME"   >> $linuxGrubCfg
	echo "    module2     $linuxFileSystemLnk         $LINUX_INITRAMFS_NAME" >> $linuxGrubCfg
	if [ -n "$LINUX_IMAGE_2" ]; then
		echo "    module2     $linuxImage2            $LINUX_IMAGE_2"        >> $linuxGrubCfg
	fi
	echo "}"                                                                 >> $linuxGrubCfg
}


# 1. search the marker file and set the $efiPart variable to the "marked" EFI-Partition
# 2. cut of the partition from $efiPart and save it to $diskHint(e.g. hd0,gpt1 => hd0,)
# afterwards $diskHint can be supplied to the "search" method as a hint (-h).
# With this we can prefer the Windows/arimg/RTH that is installed on the current harddisk (where we have installed the GRUB).
# UC1: RTH and Win on 	same 		CFast => hint is good
# UC2: RTH and Win on 	differnt 	CFasts => hint is bad, but search continues 
# UC3: RTH and Win on	same		CFast, but this combination is on the other CFast too(SACME) => hint is good and neccessary
function _addDiskDetectMethod()
{
	local grubCfg=$1
	local efiPartMarkerFilePath=$2

	echo "search -f $efiPartMarkerFilePath -s efiPart"       >> $grubCfg
	echo "regexp --set=1:diskHint \"(hd[0-9]{1,2},)\" \"\${efiPart}\" "  >> $grubCfg
}

function _addGrub2ArimgEntry()
{
	local arimgGrubCfg=$1

	checkLastParam $arimgGrubCfg "no grub.cfg file given."

	logWriteDebug "adding grub2 entry for ARemb"

	local rthPath="/SYSTEM/RTH"
	local rthFile="$rthPath/rthx86"
	echo "    insmod all_video"                                                        >> $arimgGrubCfg
	echo "    search -f   $rthFile -s -h \$diskHint"                                   >> $arimgGrubCfg
	echo "    multiboot2  $rthFile loglevel=$RTH_LOG_LEVEL tracefile=$RTH_TRACE_FILE"  >> $arimgGrubCfg
	echo "    module2     $rthPath/license.txt"                                        >> $arimgGrubCfg
	echo "    module2     $rthPath/ARemb.txt"                                          >> $arimgGrubCfg
	echo "    module2     /arimg          arimg"                                       >> $arimgGrubCfg
}

function _addGrubDefaults()
{
	local grubConfFile=$1

	checkLastParam $grubConfFile "no grub.cfg file given."

	logWriteDebug "adding grub2 defaults"


	local timeout="1"
	if [ -n "$GRUB_UEFI_TIMEOUT" ] ; then
		timeout=$GRUB_UEFI_TIMEOUT
	fi
	echo "set timeout=$timeout"                         >> $grubConfFile
	echo "set default=\"$GRUB_AREMB_BOOT_ENTRY_NAME\""  >> $grubConfFile
}
