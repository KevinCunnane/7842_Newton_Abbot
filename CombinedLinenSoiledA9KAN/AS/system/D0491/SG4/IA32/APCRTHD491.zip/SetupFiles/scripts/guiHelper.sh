#!/bin/bash

showProgressDialog()
{
	local percent=$1
	local title=$2
	local message=$3
	
	checkLastParam "$message" "no progress message given."
	
	logWriteDebug "$message $percent%"
	
	echo "$percent" | dialog --title "$title" --gauge "$message\n\nPlease wait..." 10 70 0
}

showInstProgress()
{
	local percent=$1
	checkLastParam "$percent" "no percent value given."
	
	local device=$2
	
	if [ -z "$device" ]; then
		device="B&R Hypervisor"
	fi
	local instTitle="$device Installation"
	local instMessage="\n$device is going to be installed."
	
	showProgressDialog "$percent" "$instTitle" "$instMessage"
}

showUninstProgress()
{
	local percent=$1
	checkLastParam "$percent" "no percent value given."

	# optional
	local device=$2
	
	if [ -z "$device" ]; then
		device="B&R Hypervisor"
	fi
	local uninstTitle="$device Uninstallation"
	local uninstMessage="\n$device is going to be uninstalled."
	
	showProgressDialog "$percent" "$uninstTitle" "$uninstMessage"
}