#!/bin/bash
# uefiUninstallationCallFileCfg.sh - perform the UEFI B&R hypervisor uninstallation.

# Uebergabeparameter
DEBUG=1
SETUP_DIR=$1
SHELL_SCRIPT_DIR=$2
UNINSTALL_FILE=$3

source "${SHELL_SCRIPT_DIR}/helper.sh"
# start index vorgeben!
mountedDirIndex=100

function getDeviceFromAhciPort()
{
    local __dev=$1
    local port=$2
    local dev=
    
    logWriteDebugFunction "getDeviceFromAhciPort($__dev, $port)"

	checkLastParam $port "no ahci port given."

    dev=$(lsscsi | grep "\\[$port:" | rev | sed 's/^ *//g' | cut -d ' ' -f 1 | rev)

	eval "${__dev}='${dev}'"
}

# delDir <ahciPort> <partNr> <dirName>
function delDir()
{
	local ahciPort=$1
	local partNr=$2
	local dir=$3
	
	logWriteDebugFunction "delDir($ahciPort, $partNr, $dir)"
		
	checkLastParam $dir "no directory given."
	
	getDeviceFromAhciPort device $ahciPort
	mountPartition mountedPartDir $device$partNr
	
	#spaces must be escaped " " => "\ "
	local escapedDir=$(echo $dir | sed 's/ /\\ /g') 
	
    logWriteDebugFunctionCall "rm -r $mountedPartDir$escapedDir"
    umountDir $mountedPartDir
}

# mvDir <ahciPort> <partNr> <srcDirName> <tgtDirName>
function mvDir()
{
    local ahciPort=$1
    local partNr=$2
    local srcDir=$3
    local tgtDir=$4

    logWriteDebugFunction "mvDir($ahciPort, $partNr, $srcDir, $tgtDir)"
		
	checkLastParam $tgtDir "no target directory given."
	
	getDeviceFromAhciPort device $ahciPort 
	mountPartition mountedPartDir $device$partNr
    logWriteDebugFunctionCall "mv $mountedPartDir$srcDir $mountedPartDir$tgtDir"
    umountDir $mountedPartDir
}

# delPart <ahciPort> <partNr>
function delPart()
{
    local ahciPort=$1
    local partNr=$2

    logWriteDebugFunction "delPart($ahciPort, $partNr)"
		
	checkLastParam $partNr "no partition number given."
	
	getDeviceFromAhciPort device $ahciPort 
	logWriteDebugFunctionCall "parted -s $device rm $partNr"
}

# delEfiBootEntry <efiBootEntryDescription>
function delEfiBootEntry()
{
    local entryDescription=$1

    logWriteDebugFunction "delEfiBootEntry($entryDescription)"

    checkLastParam $entryDescription "no efi entry description given."
    
    local bootEntry=$(efibootmgr | grep "$entryDescription" | head -c 8 | tail -c 4)
    logWriteDebugFunctionCall "efibootmgr -b $bootEntry -B"
}

#uninstall file aufrufen
source "$UNINSTALL_FILE"
