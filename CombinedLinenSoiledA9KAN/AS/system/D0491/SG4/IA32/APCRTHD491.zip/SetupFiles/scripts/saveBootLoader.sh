#!/bin/bash

SAVED_MASTER_BOOT_RECORD_FILE_NAME="SavedBootloader.mbr"

SECTORS_TO_SAVE=128

#########################################################
# Saves the boot loader of the given partition
# (MBR and the following $SECTORS_TO_SAVE-1 sectors)
#  $1 ... device
#  $2 ... partition number
#  $3 ... GPOS
##########################################################
function saveBootLoader() {

	local device=$1
	local partNr=$2
	local BOOT_LOADER_BACKUP_ERROR="Backup of original boot loader failed"

	logWriteDebugFunction "saveBootLoader($device, $partNr)"

	checkLastParam $partNr "no partNr given. saveBootLoader($device, $partNr)"

	# mount boot partition 
	local BootDir=
	local bootLoaderBackup=

	mountPartition BootDir $device$partNr
	retv=$?
	if [ "$retv" != "0" ]; then
		let partNr=$partNr+1
		mountPartition BootDir $device$partNr
		retv=$?
	fi

	if [ "$retv" = "0" ]; then
		bootLoaderBackup=$BootDir"/"$SAVED_MASTER_BOOT_RECORD_FILE_NAME

		# save MBR if not already done
		if [ ! -e "$bootLoaderBackup" ]; then
			# save original MBR (sector 0) + Grub Stage 1.5 (sectors 1-$SECTORS_TO_SAVE)
			logWriteDebugFunctionCall "dd if=$device of=$bootLoaderBackup bs=512 count=$SECTORS_TO_SAVE"
			retv=$?
			if [ "$retv" = "0" ]; then
				logWriteInfo "boot loader backup created"
			else				# error => delete corrupt file
				logWriteDebugFunctionCall "rm $bootLoaderBackup"
				logWriteError "$BOOT_LOADER_BACKUP_ERROR" "The original boot loader could not be backuped."
			fi
		else
			logWriteError "$BOOT_LOADER_BACKUP_ERROR" "A backup of the original boot loader already exists."
		fi
		umountDir $BootDir
	else
		logWriteError "$BOOT_LOADER_BACKUP_ERROR" "There is no partition available where to backup the original boot loader."
	fi
}

#########################################################
# Restores the master boot record from the given partition
#  $1 ... device
#  $2 ... partition number
##########################################################
function restoreBootLoader() {
	local device=$1
	local partNr=$2
	local BOOT_LOADER_RESTORE_ERROR="Restore of original boot loader failed"

	logWriteDebugFunction "restoreBootLoader($device, $partNr)"

	checkLastParam $partNr "no partNr given. restoreBootLoader ($device, $partNr)"

	# mount boot partition
	local BootDir=
	local bootLoaderBackup=

	mountPartition BootDir $device$partNr
	local retv=$?
	if [ "$retv" != "0" ]; then
		let partNr=$partNr+1
		mountPartition BootDir $device$partNr
		retv=$?
	fi

	if [ "$retv" = "0" ] ;then
		# windows
		bootLoaderBackup=$BootDir"/"$SAVED_MASTER_BOOT_RECORD_FILE_NAME
		if [ -e "$bootLoaderBackup" ] ; then
			# restore MBR
			logWriteDebugFunctionCall "dd if=$bootLoaderBackup of=$device bs=446 count=1"
			retv=$?
			if [ "$retv" = "0" ]; then			#Bootsektor-Signatur setzen
				#seek=250 && bs=2 => skip 510bytes (0-509, write to byte 510, 511)
				logWriteDebug "writing boot sector signature 0x55AA"
				echo -e "\x55\xaa" | awk '{printf "%s\n", $_}' | dd of=$device bs=2 seek=255 count=1 &>> $INSTALL_LOG_FILE
				retv=$?
				if [ "$retv" = "0" ]; then
					let sectors=$SECTORS_TO_SAVE-1
					logWriteDebugFunctionCall "dd if=$bootLoaderBackup of=$device bs=512 skip=1 seek=1 count=$sectors"
					retv=$?
					if [ "$retv" = "0" ]; then		# well done => can delete saved MBR file
						logWriteDebugFunctionCall "rm $bootLoaderBackup"
						logWriteInfo "Original MBR restored"
					else
						logWriteError "$BOOT_LOADER_RESTORE_ERROR" "The original boot loader could not be restored ($sectors sectors)."
					fi
				else
					logWriteError "$BOOT_LOADER_RESTORE_ERROR" "The original boot loader could not be restored because the boot sector signature could not be written."
				fi
			else
				logWriteError "$BOOT_LOADER_RESTORE_ERROR" "The original boot loader could not be restored (MBR)."
			fi
		else
			logWriteError "$BOOT_LOADER_RESTORE_ERROR" "The backup of the original boot loader could not be found."
		fi
		umountDir $BootDir
	else
		logWriteError "$BOOT_LOADER_RESTORE_ERROR" "The partition with the backup of the original boot loader could not be found."
	fi
}

# checks 
function getGpos() {
	local __gpos=$1 
	local grubDev=$2
	local grubPartNr=$3
	local bootMBR=$4
	local gpos=

	logWriteDebugFunction "getGpos($__gpos, $grubDev, $grubPartNr, $bootMBR)"

	checkLastParam $bootMBR "no master boot record given."

	gpos=$(echo $bootMBR | sed 's/  */ /g' | sed -e 's/^[ \t]*//')   #trim spaces, remove leading spaces

	logWriteDebug "detected GPOS: $gpos"

	eval "${__gpos}='${gpos}'"
}
