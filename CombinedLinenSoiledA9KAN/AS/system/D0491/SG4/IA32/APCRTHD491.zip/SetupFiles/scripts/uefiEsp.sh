#!/bin/bash
# uefiEsp.sh - saves and restores the ESP.
EXT_SAVED=".saved"
STARTUP_NSH="startup.nsh"

EFI_DIR="/EFI"

function getEspPartition()
{
	local __espDevice=$1
	local __espPartNr=$2
	local device=
	local partNr=
	local i=

	logWriteDebugFunction "getEspPartition($__espDevice, $__espPartNr)"

	checkLastParam ${__espPartNr} "no partition number variable given."

	for (( i=0; i<${#partitionFlag[@]}; i++ ))
	do
		local currFlags=${partitionFlag[$i]}
		local esp=$(echo $currFlags | grep "esp") 
		if [ -n "$esp" ] ; then
			device=${partitionDevice[$i]}
			partNr=${partitionPartNrAll[$i]}
			break
		fi
	done
	
	eval "${__espDevice}='${device}'"
	eval "${__espPartNr}='${partNr}'"
}

function saveEspData()
{
    local espDevice=$1
    local espPartNr=$2
	local espPartDir=
	local efiDir=
	local efiDirSaved=
	local EFI_BACKUP_ERROR="Backup of EFI files failed"

	logWriteDebugFunction "saveEspData($espDevice, $espPartNr)"

	checkLastParam $espPartNr "no partition number given."

	mountPartition espPartDir $espDevice$espPartNr

	efiDir=$espPartDir$EFI_DIR
	efiDirSaved=$espPartDir$EFI_DIR$EXT_SAVED
	if [ -e "$efiDir" ] ; then
		if [ ! -e "$efiDirSaved" ] ; then
			logWriteDebugFunctionCall "mv $efiDir $efiDirSaved"
			logWriteInfo "backup of original EFI files created"
			
			getAhciPortFromDevice ahciPort $espDevice
			
			logWriteAddUninstallCmd "delDir $ahciPort $espPartNr $EFI_DIR"
			logWriteAddUninstallCmd "mvDir $ahciPort $espPartNr $EFI_DIR$EXT_SAVED $EFI_DIR"
			
		else
			logWriteError "$EFI_BACKUP_ERROR" "A backup of the original EFI files already exists."
		fi
		if [ ! -e "$efiDir/$STARTUP_NSH$EXT_SAVED" ] && [ -e $efiDir/$STARTUP_NSH ]; then
			logWriteDebugFunctionCall "mv $efiDir/$STARTUP_NSH $efiDir/$STARTUP_NSH$EXT_SAVED"
		fi
	else
		logWriteFatal "Wrong EFI directory!"
	fi

	logWriteDebugFunctionCall "umountDir $espPartDir"
	
	logWriteInfo "EFI system partition backup created"
}

function copyWindowsEfiDir()
{
	local espDir=$1
	local efiDir=
	local efiDirSaved=

	logWriteDebugFunction "copyWindowsEfiDir($espDir)"

	checkLastParam $espDir "no esp directory given."

	efiDir=$espDir$EFI_DIR
	efiDirSaved=$efiDir$EXT_SAVED
	logWriteDebugFunctionCall "cp -r $efiDirSaved/* $efiDir"
}

function restoreEspData()
{
	local espDevice=$1
	local espPartNr=$2
	local espPartDir=
	local efiDir=
	local efiDirSaved=
	local EFI_RESTORE_ERROR="Restore of EFI files failed"

	logWriteDebugFunction "restoreEspData($espDevice, $espPartNr)"

	checkLastParam $espPartNr "no partition number given."

	mountPartition espPartDir $espDevice$espPartNr

	efiDir=$espPartDir$EFI_DIR
	efiDirSaved=$espPartDir$EFI_DIR$EXT_SAVED
	if [ -e "$efiDir" ]; then
		if [ -e "$efiDirSaved" ] ; then
			logWriteDebugFunctionCall "rm -r $efiDir"
			logWriteDebugFunctionCall "mv $efiDirSaved $efiDir"
		else
		logWriteError "$EFI_RESTORE_ERROR" "There is no backup of the original EFI files available."
		fi
		if [ -e "$efiDir/$STARTUP_NSH" ] ; then
			logWriteDebugFunctionCall "rm $efiDir/$STARTUP_NSH"
		fi
		if [ -e "$efiDir/$STARTUP_NSH$EXT_SAVED" ] ; then
			logWriteDebugFunctionCall "mv $efiDir/$STARTUP_NSH$EXT_SAVED $efiDir/$STARTUP_NSH"
		fi
	else
		logWriteFatal "Wrong EFI directory!"
	fi
	logWriteDebugFunctionCall "umountDir $espPartDir"

	logWriteInfo "EFI system partition restored"
	logWriteInfo "Grub2 uninstalled"
}
