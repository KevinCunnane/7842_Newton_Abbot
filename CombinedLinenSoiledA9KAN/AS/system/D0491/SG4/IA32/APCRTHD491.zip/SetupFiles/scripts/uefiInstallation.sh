#!/bin/bash
# installUefi.sh - perform the UEFI B&R hypervisor installation.

function doUefiInstallation()
{
	local instTitle="$AREMB_DIALOG_INSTALL_TITLE"
	local instMessage="B&R Hypervisor is going to be installed."
	#generate random filename to mark the EFI-Partition where the BR Hyp GRUB is installed
	#For the filename a constant token is concatenated with a 10-char string with letters (capital and small) and numbers
	local efiPartMarkerFileName="efiPartMarker_$(cat /dev/urandom | tr -dc 'a-zA-Z0-9' | fold -w 10 | head -n 1).efi"
	
	showInstProgress "0"
	logWriteInstallStart "B&R Hypervisor $efiPartMarkerFileName"
	
	logWriteInitUninstallFile 

	# detect ESP partition
	getEspPartition espDevice espPartNr
	showInstProgress "10"

	# save existing ESP data
	#saveEspData $espDevice $espPartNr
	showInstProgress "20"

	#AR:
	# - create partition and format it with FAT
	createARPartitions arDevice arPartPrefix arPartNr
	showInstProgress "35"

	# - copy Basis AR
	installInitialARemb $arDevice "$arPartPrefix" $arPartNr
	showInstProgress "50"

	#hypervisor: create hypervisor configuration
	installHypervisorFiles $arDevice "$arPartPrefix" $arPartNr
	showInstProgress "60"

    	#grub: install grub in the ESP
	installUefiGrub2 gposName bootline $efiPartMarkerFileName $espDevice $espPartNr 
	showInstProgress "80"

	#create hypervisor configuration
	installUefiHypervisorCfg $espDevice $arDevice "$arPartPrefix" $arPartNr $efiPartMarkerFileName $gposName "$bootline" 
	showInstProgress "90"

	logWriteInstallFinished "B&R Hypervisor"
	showInstProgress "100"
}
