#!/bin/bash

function installHypervisorCfg() {
	local gposDev=$1			# device assigned to GPOS per default
	local arDev=$2				# device of AR
	local arPartNr=$3			# partition number of AR system directory
	local extPartNr=$4			# partition number of the extended partition
	local gpos=$5
	local bootline="$6"

	logWriteDebugFunction "installHypervisorCfg($gposDev, $arDev, $arPartNr, $extPartNr, $gpos, $bootline)"

	checkLastParam $bootline "no bootline given."

	getPartitionPrefix partPrefix $arDev
	mountPartition arembSysPart $arDev$partPrefix$arPartNr

	local arembRthDir=$arembSysPart$RTH_DIR
	local out=$arembRthDir/$RTH_CFG

	createRthCfgHeader $out

	if [ "${arDev:0:9}" = "/dev/nvme" ]; then
		getPciNvmeDriveParameters pciBus pciDevice pciFunction
		let extPartNr=$extPartNr-1
		addRthCfgNvmeDriveEntry $gposDev $arDev $extPartNr $out $pciBus $pciDevice $pciFunction
	else
		getPciDriveParameters pciBus pciDevice pciFunction
		let extPartNr=$extPartNr-1
		addRthCfgDriveEntry $gposDev $arDev $extPartNr $out $pciBus $pciDevice $pciFunction
	fi
	addRthCfgIoRanges $out
	addRthCfgIRQ $out
	_addRthCfgLegacyImagesAndBootline $gpos $bootline $out
	addRthCfgOsEntries $gpos $out
	_addRthCfgPci $out $pciBus $pciDevice $pciFunction
	addRthCfgShmEntries $out
	addRthCfgSystemEntries $out
	addRthCfgTimeSyncEntries $out

	logWriteFile $out

	umountDir $arembSysPart
}
